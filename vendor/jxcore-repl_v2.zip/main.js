function FakeSocket() {
    var self = this;
    EventTarget.call(self);
}
FakeSocket.prototype.__proto__ = EventTarget.prototype;
FakeSocket.prototype.emit = function (type, data) {
	var self = this;
	setTimeout(function() {
		self.trigger(type, data);
	}, 5);
};

var bash = new Bash(document.getElementById('bash'));
var socket;

bash.on('stdin', function (command) {
    if (socket) {
        socket.emit('stdin', command);
    } else {
        alert('Wait for socket initialization.');
    }
});

function connect(host, callback) {
	socket = new FakeSocket();
    callback();
}

function start(host) {
    if (host) {
        bash.write('Connected! host: ' + host + '\n');
    } else {
        bash.write('Enable wifi or mobile internet to connect from browser\n');
    }

    bash.write('> ');

    socket.on('stdout', function (text) {
        bash.write(text);
    });

    socket.on('stdin', function (command) {
		var self = this;
		if (true) {
			//should be sync
			bash.write(command + '\n');
			self.emit('stdout', "result 1\n");
			self.emit('stdout', "result 2\n");
			self.emit('stdout', "> ");
		}
    });

    socket.on('disconnect', function () {
        if (confirm('You have been disconnected. Try reconnecting?')) {
            window.location.reload();
        }
    });
}

(function check() {
	var host = location.protocol + '//' + location.host;
	connect(host, function () {
		start(host);
	});
})();
