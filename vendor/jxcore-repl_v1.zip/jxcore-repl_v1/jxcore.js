window.jxcore="none";
