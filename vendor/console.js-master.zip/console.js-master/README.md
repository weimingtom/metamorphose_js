Console.js 
===


###### 一款兼容IE的JS模拟控制台 by AdamChuan 
<br>
<br>
<br>
<br>
######只需引用 console.js即可使用， 无全局污染
    <script type="text/javascript" src= "console.js"></script>
######注意 console.js 需和 console.css放在同一目录,且需运行在服务器环境