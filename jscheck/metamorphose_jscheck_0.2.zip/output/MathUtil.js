
/**
* 
* @class MathUtil
* @constructor 
*/


/**
* 
* @method toDegrees
* @static
* @param {Object} rad
*/


/**
* 
* @method toRadians
* @static
* @param {Object} deg
*/

