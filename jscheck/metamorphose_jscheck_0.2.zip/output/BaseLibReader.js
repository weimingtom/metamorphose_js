
/**
* 
* @class BaseLibReader
* @constructor 
* @param {Object} L
* @param {Object} f
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} l
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method readMultiBytes
* @param {Object} cbuf
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method reset
*/


/**
* 
* @property _s
* @type Object
*/


/**
* 
* @property _i
* @type Object
*/


/**
* 
* @property _mark
* @type Object
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _f
* @type Object
*/

