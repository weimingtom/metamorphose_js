
/**
* 
* @class OutputStream
* @constructor 
*/


/**
* 
* @method close
*/


/**
* 
* @method flush
*/


/**
* 
* @method write
* @param {Object} b
*/


/**
* 
* @method writeBytes
* @param {Object} b
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method writeChar
* @param {Object} b
*/


/**
* 
* @method throwError
* @param {Object} str
*/

