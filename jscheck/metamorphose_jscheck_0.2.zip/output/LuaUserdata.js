
/**
* 
* @class LuaUserdata
* @constructor 
* @param {Object} o
*/


/**
* 
* @method getUserdata
*/


/**
* 
* @method getMetatable
*/


/**
* 
* @method setMetatable
* @param {Object} metatable
*/


/**
* 
* @method getEnv
*/


/**
* 
* @method setEnv
* @param {Object} env
*/


/**
* 
* @property _userdata
* @type Object
*/


/**
* 
* @property _metatable
* @type Object
*/


/**
* 
* @property _env
* @type Object
*/

