
/**
* 
* @class Enumeration
* @constructor 
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/

