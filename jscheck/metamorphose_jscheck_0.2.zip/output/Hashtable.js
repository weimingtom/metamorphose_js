
/**
* 
* @class Hashtable
* @constructor 
* @param {Object} initialCapacity
*/


/**
* 
* @method rehash
*/


/**
* 
* @method keys
*/


/**
* 
* @method _get
* @param {Object} key
*/


/**
* 
* @method put
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method remove
* @param {Object} key
*/


/**
* 
* @property _dic
* @type Object
*/

