
/**
* 
* @class LuaInternal
* @constructor 
*/


/**
* 
* @method init1
* @param {Object} _in
* @param {Object} chunkname
*/


/**
* 
* @method init2
* @param {Object} _in
* @param {Object} chunkname
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @property _stream
* @type Object
*/


/**
* 
* @property _reader
* @type Object
*/


/**
* 
* @property _chunkname
* @type Object
*/

