
/**
* 
* @class StringLib
* @constructor 
* @param {Object} which
*/


/**
* 
* @property BYTE
* @type Object
* @final
*/


/**
* 
* @property CHAR
* @type Object
* @final
*/


/**
* 
* @property DUMP
* @type Object
* @final
*/


/**
* 
* @property FIND
* @type Object
* @final
*/


/**
* 
* @property FORMAT
* @type Object
* @final
*/


/**
* 
* @property GFIND
* @type Object
* @final
*/


/**
* 
* @property GMATCH
* @type Object
* @final
*/


/**
* 
* @property GSUB
* @type Object
* @final
*/


/**
* 
* @property LEN
* @type Object
* @final
*/


/**
* 
* @property LOWER
* @type Object
* @final
*/


/**
* 
* @property MATCH
* @type Object
* @final
*/


/**
* 
* @property REP
* @type Object
* @final
*/


/**
* 
* @property REVERSE
* @type Object
* @final
*/


/**
* 
* @property SUB
* @type Object
* @final
*/


/**
* 
* @property UPPER
* @type Object
* @final
*/


/**
* 
* @property GMATCH_AUX
* @type Object
* @final
*/


/**
* 
* @property GMATCH_AUX_FUN
* @type Object
* @final
*/


/**
* 
* @method formatISO
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method byteFunction
* @static
* @param {Object} L
*/


/**
* 
* @method charFunction
* @static
* @param {Object} L
*/


/**
* 
* @method dump
* @static
* @param {Object} L
*/


/**
* 
* @method findAux
* @static
* @param {Object} L
* @param {Object} isFind
*/


/**
* 
* @method find
* @static
* @param {Object} L
*/


/**
* 
* @method gmatch
* @static
* @param {Object} L
*/


/**
* 
* @method gmatchaux
* @static
* @param {Object} L
*/


/**
* 
* @method gsub
* @static
* @param {Object} L
*/


/**
* 
* @method addquoted
* @static
* @param {Object} L
* @param {Object} b
* @param {Object} arg
*/


/**
* 
* @method format
* @static
* @param {Object} L
*/


/**
* 
* @method len
* @static
* @param {Object} L
*/


/**
* 
* @method lower
* @static
* @param {Object} L
*/


/**
* 
* @method match
* @static
* @param {Object} L
*/


/**
* 
* @method rep
* @static
* @param {Object} L
*/


/**
* 
* @method reverse
* @static
* @param {Object} L
*/


/**
* 
* @method posrelat
* @static
* @param {Object} pos
* @param {Object} s
*/


/**
* 
* @method sub
* @static
* @param {Object} L
*/


/**
* 
* @method upper
* @static
* @param {Object} L
*/


/**
* 
* @method lmemfind
* @static
* @param {Object} s1
* @param {Object} l1
* @param {Object} s2
* @param {Object} l2
*/


/**
* 
* @method strpbrk
* @static
* @param {Object} s
* @param {Object} _set
*/


/**
* 
* @property _which
* @type Object
*/

