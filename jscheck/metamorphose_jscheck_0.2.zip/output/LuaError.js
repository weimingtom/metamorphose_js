
/**
* 
* @class LuaError
* @constructor 
* @param {Object} errorStatus
*/


/**
* 
* @method getErrorStatus
*/


/**
* 
* @property message
* @type Object
*/


/**
* 
* @property _errorStatus
* @type Object
*/

