
/**
* 
* @class Character
* @constructor 
*/


/**
* 
* @method isUpperCase
* @static
* @param {Object} ch
*/


/**
* 
* @method isLowerCase
* @static
* @param {Object} ch
*/


/**
* 
* @method isDigit
* @static
* @param {Object} ch
*/


/**
* 
* @method toLowerCase
* @static
* @param {Object} ch
*/

