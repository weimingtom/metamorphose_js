
/**
* 
* @class CallInfo
* @constructor 
*/


/**
* 
* @method init
* @param {Object} func
* @param {Object} base
* @param {Object} top
* @param {Object} nresults
*/


/**
* 
* @method setSavedpc
* @param {Object} pc
*/


/**
* 
* @method getSavedpc
*/


/**
* 
* @method getFunc
*/


/**
* 
* @method res
*/


/**
* 
* @method getBase
*/


/**
* 
* @method getTop
*/


/**
* 
* @method setTop
* @param {Object} top
*/


/**
* 
* @method getNresults
*/


/**
* 
* @method getTailcalls
*/


/**
* 
* @method tailcall
* @param {Object} baseArg
* @param {Object} topArg
*/


/**
* 
* @property _savedpc
* @type Object
*/


/**
* 
* @property _func
* @type Object
*/


/**
* 
* @property _base
* @type Object
*/


/**
* 
* @property _top
* @type Object
*/


/**
* 
* @property _nresults
* @type Object
*/


/**
* 
* @property _tailcalls
* @type Object
*/

