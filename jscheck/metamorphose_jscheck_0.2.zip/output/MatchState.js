
/**
* 
* @class MatchState
* @constructor 
* @param {Object} L
* @param {Object} src
* @param {Object} end
*/


/**
* 
* @method captureLen
* @param {Object} i
*/


/**
* 
* @method captureInit
* @param {Object} i
*/


/**
* 
* @method capture
* @param {Object} i
*/


/**
* 
* @method capInvalid
*/


/**
* 
* @method malBra
*/


/**
* 
* @method capUnfinished
*/


/**
* 
* @method malEsc
*/


/**
* 
* @method check_capture
* @param {Object} l
*/


/**
* 
* @method capture_to_close
*/


/**
* 
* @method classend
* @param {Object} p
* @param {Object} pi
*/


/**
* 
* @method match_class
* @static
* @param {Object} c
* @param {Object} cl
*/


/**
* 
* @method matchbracketclass
* @static
* @param {Object} c
* @param {Object} p
* @param {Object} pi
* @param {Object} ec
*/


/**
* 
* @method singlematch
* @static
* @param {Object} c
* @param {Object} p
* @param {Object} pi
* @param {Object} ep
*/


/**
* 
* @method matchbalance
* @param {Object} si
* @param {Object} p
* @param {Object} pi
*/


/**
* 
* @method max_expand
* @param {Object} si
* @param {Object} p
* @param {Object} pi
* @param {Object} ep
*/


/**
* 
* @method min_expand
* @param {Object} si
* @param {Object} p
* @param {Object} pi
* @param {Object} ep
*/


/**
* 
* @method start_capture
* @param {Object} si
* @param {Object} p
* @param {Object} pi
* @param {Object} what
*/


/**
* 
* @method end_capture
* @param {Object} si
* @param {Object} p
* @param {Object} pi
*/


/**
* 
* @method match_capture
* @param {Object} si
* @param {Object} l
*/


/**
* 
* @property L_ESC
* @type Object
* @final
*/


/**
* 
* @property SPECIALS
* @type Object
* @final
*/


/**
* 
* @property CAP_UNFINISHED
* @type Object
* @final
*/


/**
* 
* @property CAP_POSITION
* @type Object
* @final
*/


/**
* 
* @method match
* @param {Object} si
* @param {Object} p
* @param {Object} pi
*/


/**
* 
* @method onecapture
* @param {Object} i
* @param {Object} s
* @param {Object} e
*/


/**
* 
* @method push_onecapture
* @param {Object} i
* @param {Object} s
* @param {Object} e
*/


/**
* 
* @method push_captures
* @param {Object} s
* @param {Object} e
*/


/**
* 
* @method adds
* @param {Object} b
* @param {Object} si
* @param {Object} ei
*/


/**
* 
* @method addvalue
* @param {Object} b
* @param {Object} si
* @param {Object} ei
*/


/**
* 
* @method getEnd
*/


/**
* 
* @method setLevel
* @param {Object} level
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _src
* @type Object
*/


/**
* 
* @property _end
* @type Object
*/


/**
* 
* @property _level
* @type Object
*/


/**
* 
* @property _capture
* @type Object
*/

