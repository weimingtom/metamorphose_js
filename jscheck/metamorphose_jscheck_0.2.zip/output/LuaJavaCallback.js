
/**
* 
* @class LuaJavaCallback
* @constructor 
* @param {Object} L
*/

