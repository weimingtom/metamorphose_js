
/**
* 
* @class Lua
* @constructor 
* @param {Object} L
*/


/**
* 
* @property D
* @type Object
* @final
*/


/**
* 
* @property VERSION
* @type Object
* @final
*/


/**
* 
* @property RELEASE
* @type Object
* @final
*/


/**
* 
* @property VERSION_NUM
* @type Object
* @final
*/


/**
* 
* @property COPYRIGHT
* @type Object
* @final
*/


/**
* 
* @property AUTHORS
* @type Object
* @final
*/


/**
* 
* @method initCiv
*/


/**
* 
* @method __ci
*/


/**
* 
* @property LFIELDS_PER_FLUSH
* @type Object
* @final
*/


/**
* 
* @property MAXTAGLOOP
* @type Object
* @final
*/


/**
* 
* @property LUA_ERROR
* @type Object
* @final
*/


/**
* 
* @property MAXVARS
* @type Object
* @final
*/


/**
* 
* @property MAXSTACK
* @type Object
* @final
*/


/**
* 
* @property MAXUPVALUES
* @type Object
* @final
*/


/**
* 
* @property NUMBER
* @type Object
* @final
*/


/**
* 
* @property SPARE_SLOT
* @type Object
* @final
*/


/**
* 
* @property LOADED
* @type Object
* @final
*/


/**
* 
* @property MULTRET
* @type Object
* @final
*/


/**
* 
* @property NIL
* @type Object
* @final
*/


/**
* 
* @property TNONE
* @type Object
* @final
*/


/**
* 
* @property TNIL
* @type Object
* @final
*/


/**
* 
* @property TBOOLEAN
* @type Object
* @final
*/


/**
* 
* @property TNUMBER
* @type Object
* @final
*/


/**
* 
* @property TSTRING
* @type Object
* @final
*/


/**
* 
* @property TTABLE
* @type Object
* @final
*/


/**
* 
* @property TFUNCTION
* @type Object
* @final
*/


/**
* 
* @property TUSERDATA
* @type Object
* @final
*/


/**
* 
* @property TTHREAD
* @type Object
* @final
*/


/**
* 
* @property NUM_TAGS
* @type Object
* @final
*/


/**
* 
* @property TYPENAME
* @type Object
* @final
*/


/**
* 
* @property MINSTACK
* @type Object
* @final
*/


/**
* 
* @property YIELD
* @type Object
* @final
*/


/**
* 
* @property ERRRUN
* @type Object
* @final
*/


/**
* 
* @property ERRSYNTAX
* @type Object
* @final
*/


/**
* 
* @property ERRMEM
* @type Object
* @final
*/


/**
* 
* @property ERRERR
* @type Object
* @final
*/


/**
* 
* @property ERRFILE
* @type Object
* @final
*/


/**
* 
* @property GCSTOP
* @type Object
* @final
*/


/**
* 
* @property GCRESTART
* @type Object
* @final
*/


/**
* 
* @property GCCOLLECT
* @type Object
* @final
*/


/**
* 
* @property GCCOUNT
* @type Object
* @final
*/


/**
* 
* @property GCCOUNTB
* @type Object
* @final
*/


/**
* 
* @property GCSTEP
* @type Object
* @final
*/


/**
* 
* @property GCSETPAUSE
* @type Object
* @final
*/


/**
* 
* @property GCSETSTEPMUL
* @type Object
* @final
*/


/**
* 
* @property HOOKCALL
* @type Object
* @final
*/


/**
* 
* @property HOOKRET
* @type Object
* @final
*/


/**
* 
* @property HOOKLINE
* @type Object
* @final
*/


/**
* 
* @property HOOKCOUNT
* @type Object
* @final
*/


/**
* 
* @property HOOKTAILRET
* @type Object
* @final
*/


/**
* 
* @property MASKCALL
* @type Object
* @final
*/


/**
* 
* @property MASKRET
* @type Object
* @final
*/


/**
* 
* @property MASKLINE
* @type Object
* @final
*/


/**
* 
* @property MASKCOUNT
* @type Object
* @final
*/


/**
* 
* @method call
* @param {Object} nargs
* @param {Object} nresults
*/


/**
* 
* @method close
*/


/**
* 
* @method concat
* @param {Object} n
*/


/**
* 
* @method createTable
* @param {Object} narr
* @param {Object} nrec
*/


/**
* 
* @method dump
* @static
* @param {Object} _function
* @param {Object} writer
*/


/**
* 
* @method equal
* @param {Object} o1
* @param {Object} o2
*/


/**
* 
* @method error
* @param {Object} message
*/


/**
* 
* @method gc
* @param {Object} what
* @param {Object} data
*/


/**
* 
* @method getFenv
* @param {Object} o
*/


/**
* 
* @method getField
* @param {Object} t
* @param {Object} field
*/


/**
* 
* @method getGlobal
* @param {Object} name
*/


/**
* 
* @method getGlobals
*/


/**
* 
* @method getMetatable
* @param {Object} o
*/


/**
* 
* @method getRegistry
*/


/**
* 
* @method getTable
* @param {Object} t
* @param {Object} k
*/


/**
* 
* @method getTop
*/


/**
* 
* @method insert
* @param {Object} o
* @param {Object} idx
*/


/**
* 
* @method isBoolean
* @static
* @param {Object} o
*/


/**
* 
* @method isJavaFunction
* @static
* @param {Object} o
*/


/**
* 
* @method isFunction
* @static
* @param {Object} o
*/


/**
* 
* @method isMain
*/


/**
* 
* @method isNil
* @static
* @param {Object} o
*/


/**
* 
* @method isNumber
* @static
* @param {Object} o
*/


/**
* 
* @method isString
* @static
* @param {Object} o
*/


/**
* 
* @method isTable
* @static
* @param {Object} o
*/


/**
* 
* @method isThread
* @static
* @param {Object} o
*/


/**
* 
* @method isUserdata
* @static
* @param {Object} o
*/


/**
* 
* @method isValue
* @static
* @param {Object} o
*/


/**
* 
* @method lessThan
* @param {Object} o1
* @param {Object} o2
*/


/**
* 
* @method load
* @param {Object} _in
* @param {Object} chunkname
*/


/**
* 
* @method __load
* @param {Object} _in
* @param {Object} chunkname
*/


/**
* 
* @method next
* @param {Object} idx
*/


/**
* 
* @method newTable
*/


/**
* 
* @method newThread
*/


/**
* 
* @method newUserdata
* @param {Object} ref
*/


/**
* 
* @method objLen
* @static
* @param {Object} o
*/


/**
* 
* @method pcall
* @param {Object} nargs
* @param {Object} nresults
* @param {Object} ef
*/


/**
* 
* @method pop
* @param {Object} n
*/


/**
* 
* @method pushObject
* @param {Object} o
*/


/**
* 
* @method pushBoolean
* @param {Object} b
*/


/**
* 
* @method pushLiteral
* @param {Object} s
*/


/**
* 
* @method pushNil
*/


/**
* 
* @method pushNumber
* @param {Object} d
*/


/**
* 
* @method pushString
* @param {Object} s
*/


/**
* 
* @method pushValue
* @param {Object} idx
*/


/**
* 
* @method rawEqual
* @static
* @param {Object} o1
* @param {Object} o2
*/


/**
* 
* @method rawGet
* @static
* @param {Object} t
* @param {Object} k
*/


/**
* 
* @method rawGetI
* @static
* @param {Object} t
* @param {Object} i
*/


/**
* 
* @method rawSet
* @param {Object} t
* @param {Object} k
* @param {Object} v
*/


/**
* 
* @method rawSetI
* @param {Object} t
* @param {Object} i
* @param {Object} v
*/


/**
* 
* @method register
* @param {Object} name
* @param {Object} f
*/


/**
* 
* @method resume
* @param {Object} narg
*/


/**
* 
* @method setFenv
* @param {Object} o
* @param {Object} table
*/


/**
* 
* @method setField
* @param {Object} t
* @param {Object} name
* @param {Object} v
*/


/**
* 
* @method setMetatable
* @param {Object} o
* @param {Object} mt
*/


/**
* 
* @method setGlobal
* @param {Object} name
* @param {Object} value
*/


/**
* 
* @method setTable
* @param {Object} t
* @param {Object} k
* @param {Object} v
*/


/**
* 
* @method setTop
* @param {Object} n
*/


/**
* 
* @method getStatus
*/


/**
* 
* @method setStatus
* @param {Object} status
*/


/**
* 
* @method tableKeys
* @param {Object} t
*/


/**
* 
* @method toBoolean
* @param {Object} o
*/


/**
* 
* @method toInteger
* @param {Object} o
*/


/**
* 
* @method toNumber
* @param {Object} o
*/


/**
* 
* @method toString
* @param {Object} o
*/


/**
* 
* @method toThread
* @param {Object} o
*/


/**
* 
* @method toUserdata
* @param {Object} o
*/


/**
* 
* @method type
* @param {Object} idx
*/


/**
* 
* @method ___type
* @param {Object} s
*/


/**
* 
* @method ____type
* @static
* @param {Object} o
*/


/**
* 
* @method typeName
* @static
* @param {Object} type
*/


/**
* 
* @method value
* @param {Object} idx
*/


/**
* 
* @method valueOfBoolean
* @static
* @param {Object} b
*/


/**
* 
* @method valueOfNumber
* @static
* @param {Object} d
*/


/**
* 
* @method xmove
* @param {Object} to
* @param {Object} n
*/


/**
* 
* @method yield
* @param {Object} nresults
*/


/**
* 
* @method absIndex
* @param {Object} idx
*/


/**
* 
* @method absIndexUnclamped
* @param {Object} idx
*/


/**
* 
* @method apiCheck
* @param {Object} cond
*/


/**
* 
* @method apiChecknelems
* @param {Object} n
*/


/**
* 
* @method argCheck
* @param {Object} cond
* @param {Object} numarg
* @param {Object} extramsg
*/


/**
* 
* @method argError
* @param {Object} narg
* @param {Object} extramsg
*/


/**
* 
* @method callMeta
* @param {Object} obj
* @param {Object} event
*/


/**
* 
* @method checkAny
* @param {Object} narg
*/


/**
* 
* @method checkInt
* @param {Object} narg
*/


/**
* 
* @method checkNumber
* @param {Object} narg
*/


/**
* 
* @method checkOption
* @param {Object} narg
* @param {Object} def
* @param {Object} lst
*/


/**
* 
* @method checkString
* @param {Object} narg
*/


/**
* 
* @method checkType
* @param {Object} narg
* @param {Object} t
*/


/**
* 
* @method doString
* @param {Object} s
*/


/**
* 
* @method errfile
* @param {Object} what
* @param {Object} fname
* @param {Object} e
*/


/**
* 
* @method findTable
* @param {Object} t
* @param {Object} fname
* @param {Object} szhint
*/


/**
* 
* @method getMetafield
* @param {Object} o
* @param {Object} event
*/


/**
* 
* @method isNoneOrNil
* @param {Object} narg
*/


/**
* 
* @method loadFile
* @param {Object} filename
*/


/**
* 
* @method loadString
* @param {Object} s
* @param {Object} chunkname
*/


/**
* 
* @method optInt
* @param {Object} narg
* @param {Object} def
*/


/**
* 
* @method optNumber
* @param {Object} narg
* @param {Object} def
*/


/**
* 
* @method optString
* @param {Object} narg
* @param {Object} def
*/


/**
* 
* @method __register
* @param {Object} name
*/


/**
* 
* @method tagError
* @param {Object} narg
* @param {Object} tag
*/


/**
* 
* @method typeNameOfIndex
* @param {Object} idx
*/


/**
* 
* @method typerror
* @param {Object} narg
* @param {Object} tname
*/


/**
* 
* @method where
* @param {Object} level
*/


/**
* 
* @method stringReader
* @static
* @param {Object} s
*/


/**
* 
* @method getInfo
* @param {Object} what
* @param {Object} ar
*/


/**
* 
* @method getStack
* @param {Object} level
*/


/**
* 
* @method setHook
* @param {Object} func
* @param {Object} mask
* @param {Object} count
*/


/**
* 
* @method auxgetinfo
* @param {Object} what
* @param {Object} ar
* @param {Object} f
* @param {Object} ci
*/


/**
* 
* @method currentline
* @param {Object} ci
*/


/**
* 
* @method currentpc
* @param {Object} ci
*/


/**
* 
* @method funcinfo
* @param {Object} ar
* @param {Object} cl
*/


/**
* 
* @method isLua
* @param {Object} callinfo
*/


/**
* 
* @method pcRel
* @static
* @param {Object} pc
*/


/**
* 
* @method dCallhook
* @param {Object} event
* @param {Object} line
*/


/**
* 
* @property MEMERRMSG
* @type Object
* @final
*/


/**
* 
* @method dSeterrorobj
* @param {Object} errcode
* @param {Object} oldtop
*/


/**
* 
* @method dThrow
* @param {Object} status
*/


/**
* 
* @method fClose
* @param {Object} level
*/


/**
* 
* @method fFindupval
* @param {Object} idx
*/


/**
* 
* @method gAritherror
* @param {Object} p1
* @param {Object} p2
*/


/**
* 
* @method gConcaterror
* @param {Object} p1
* @param {Object} p2
*/


/**
* 
* @method gCheckcode
* @param {Object} p
*/


/**
* 
* @method gErrormsg
* @param {Object} message
*/


/**
* 
* @method gOrdererror
* @param {Object} p1
* @param {Object} p2
*/


/**
* 
* @method gRunerror
* @param {Object} s
*/


/**
* 
* @method gTypeerror
* @param {Object} o
* @param {Object} op
*/


/**
* 
* @method __gTypeerror
* @param {Object} p
* @param {Object} op
*/


/**
* 
* @property IDSIZE
* @type Object
* @final
*/


/**
* 
* @method oChunkid
* @static
* @param {Object} source
*/


/**
* 
* @method oFb2int
* @static
* @param {Object} x
*/


/**
* 
* @method oRawequal
* @static
* @param {Object} a
* @param {Object} b
*/


/**
* 
* @method oStr2d
* @static
* @param {Object} s
* @param {Object} out
*/


/**
* 
* @property PCRLUA
* @type Object
* @final
*/


/**
* 
* @property PCRJ
* @type Object
* @final
*/


/**
* 
* @property PCRYIELD
* @type Object
* @final
*/


/**
* 
* @property NO_REG
* @type Object
* @final
*/


/**
* 
* @method OPCODE
* @static
* @param {Object} instruction
*/


/**
* 
* @method SET_OPCODE
* @static
* @param {Object} i
* @param {Object} op
*/


/**
* 
* @method ARGA
* @static
* @param {Object} instruction
*/


/**
* 
* @method SETARG_A
* @static
* @param {Object} i
* @param {Object} u
*/


/**
* 
* @method ARGB
* @static
* @param {Object} instruction
*/


/**
* 
* @method SETARG_B
* @static
* @param {Object} i
* @param {Object} b
*/


/**
* 
* @method ARGC
* @static
* @param {Object} instruction
*/


/**
* 
* @method SETARG_C
* @static
* @param {Object} i
* @param {Object} c
*/


/**
* 
* @method ARGBx
* @static
* @param {Object} instruction
*/


/**
* 
* @method SETARG_Bx
* @static
* @param {Object} i
* @param {Object} bx
*/


/**
* 
* @method ARGsBx
* @static
* @param {Object} instruction
*/


/**
* 
* @method SETARG_sBx
* @static
* @param {Object} i
* @param {Object} bx
*/


/**
* 
* @method ISK
* @static
* @param {Object} field
*/


/**
* 
* @method RK
* @param {Object} k
* @param {Object} field
*/


/**
* 
* @method __RK
* @param {Object} field
*/


/**
* 
* @method CREATE_ABC
* @static
* @param {Object} o
* @param {Object} a
* @param {Object} b
* @param {Object} c
*/


/**
* 
* @method CREATE_ABx
* @static
* @param {Object} o
* @param {Object} a
* @param {Object} bc
*/


/**
* 
* @property OP_MOVE
* @type Object
* @final
*/


/**
* 
* @property OP_LOADK
* @type Object
* @final
*/


/**
* 
* @property OP_LOADBOOL
* @type Object
* @final
*/


/**
* 
* @property OP_LOADNIL
* @type Object
* @final
*/


/**
* 
* @property OP_GETUPVAL
* @type Object
* @final
*/


/**
* 
* @property OP_GETGLOBAL
* @type Object
* @final
*/


/**
* 
* @property OP_GETTABLE
* @type Object
* @final
*/


/**
* 
* @property OP_SETGLOBAL
* @type Object
* @final
*/


/**
* 
* @property OP_SETUPVAL
* @type Object
* @final
*/


/**
* 
* @property OP_SETTABLE
* @type Object
* @final
*/


/**
* 
* @property OP_NEWTABLE
* @type Object
* @final
*/


/**
* 
* @property OP_SELF
* @type Object
* @final
*/


/**
* 
* @property OP_ADD
* @type Object
* @final
*/


/**
* 
* @property OP_SUB
* @type Object
* @final
*/


/**
* 
* @property OP_MUL
* @type Object
* @final
*/


/**
* 
* @property OP_DIV
* @type Object
* @final
*/


/**
* 
* @property OP_MOD
* @type Object
* @final
*/


/**
* 
* @property OP_POW
* @type Object
* @final
*/


/**
* 
* @property OP_UNM
* @type Object
* @final
*/


/**
* 
* @property OP_NOT
* @type Object
* @final
*/


/**
* 
* @property OP_LEN
* @type Object
* @final
*/


/**
* 
* @property OP_CONCAT
* @type Object
* @final
*/


/**
* 
* @property OP_JMP
* @type Object
* @final
*/


/**
* 
* @property OP_EQ
* @type Object
* @final
*/


/**
* 
* @property OP_LT
* @type Object
* @final
*/


/**
* 
* @property OP_LE
* @type Object
* @final
*/


/**
* 
* @property OP_TEST
* @type Object
* @final
*/


/**
* 
* @property OP_TESTSET
* @type Object
* @final
*/


/**
* 
* @property OP_CALL
* @type Object
* @final
*/


/**
* 
* @property OP_TAILCALL
* @type Object
* @final
*/


/**
* 
* @property OP_RETURN
* @type Object
* @final
*/


/**
* 
* @property OP_FORLOOP
* @type Object
* @final
*/


/**
* 
* @property OP_FORPREP
* @type Object
* @final
*/


/**
* 
* @property OP_TFORLOOP
* @type Object
* @final
*/


/**
* 
* @property OP_SETLIST
* @type Object
* @final
*/


/**
* 
* @property OP_CLOSE
* @type Object
* @final
*/


/**
* 
* @property OP_CLOSURE
* @type Object
* @final
*/


/**
* 
* @property OP_VARARG
* @type Object
* @final
*/


/**
* 
* @property SIZE_C
* @type Object
* @final
*/


/**
* 
* @property SIZE_B
* @type Object
* @final
*/


/**
* 
* @property SIZE_Bx
* @type Object
* @final
*/


/**
* 
* @property SIZE_A
* @type Object
* @final
*/


/**
* 
* @property SIZE_OP
* @type Object
* @final
*/


/**
* 
* @property POS_OP
* @type Object
* @final
*/


/**
* 
* @property POS_A
* @type Object
* @final
*/


/**
* 
* @property POS_C
* @type Object
* @final
*/


/**
* 
* @property POS_B
* @type Object
* @final
*/


/**
* 
* @property POS_Bx
* @type Object
* @final
*/


/**
* 
* @property MAXARG_Bx
* @type Object
* @final
*/


/**
* 
* @property MAXARG_sBx
* @type Object
* @final
*/


/**
* 
* @property MAXARG_A
* @type Object
* @final
*/


/**
* 
* @property MAXARG_B
* @type Object
* @final
*/


/**
* 
* @property MAXARG_C
* @type Object
* @final
*/


/**
* 
* @property BITRK
* @type Object
* @final
*/


/**
* 
* @property MAXINDEXRK
* @type Object
* @final
*/


/**
* 
* @method vmCall
* @param {Object} func
* @param {Object} r
*/


/**
* 
* @method vmConcat
* @param {Object} total
* @param {Object} last
*/


/**
* 
* @method vmEqual
* @param {Object} a
* @param {Object} b
*/


/**
* 
* @method vmEqualRef
* @param {Object} a
* @param {Object} b
*/


/**
* 
* @property NUMOP
* @type Object
* @final
*/


/**
* 
* @method vmExecute
* @param {Object} nexeccalls
*/


/**
* 
* @method iNumpow
* @static
* @param {Object} a
* @param {Object} b
*/


/**
* 
* @method vmGettable
* @param {Object} t
* @param {Object} key
* @param {Object} val
*/


/**
* 
* @method vmLessthan
* @param {Object} l
* @param {Object} r
*/


/**
* 
* @method vmLessequal
* @param {Object} l
* @param {Object} r
*/


/**
* 
* @method vmPoscall
* @param {Object} firstResult
*/


/**
* 
* @method vmPrecall
* @param {Object} func
* @param {Object} r
*/


/**
* 
* @method vmSettable
* @param {Object} t
* @param {Object} key
* @param {Object} val
*/


/**
* 
* @property NUMBER_FMT
* @type Object
* @final
*/


/**
* 
* @method vmTostring
* @static
* @param {Object} o
*/


/**
* 
* @method adjust_varargs
* @param {Object} p
* @param {Object} actual
*/


/**
* 
* @method call_binTM
* @param {Object} p1
* @param {Object} p2
* @param {Object} res
* @param {Object} event
*/


/**
* 
* @method call_orderTM
* @param {Object} p1
* @param {Object} p2
* @param {Object} event
*/


/**
* 
* @method callTM
* @param {Object} f
* @param {Object} p1
* @param {Object} p2
* @param {Object} p3
*/


/**
* 
* @method callTMres
* @param {Object} res
* @param {Object} f
* @param {Object} p1
* @param {Object} p2
*/


/**
* 
* @method __callTMres
* @param {Object} res
* @param {Object} f
* @param {Object} p1
* @param {Object} p2
*/


/**
* 
* @method get_compTM
* @param {Object} mt1
* @param {Object} mt2
* @param {Object} event
*/


/**
* 
* @method tagmethod
* @param {Object} o
* @param {Object} event
*/


/**
* 
* @method __tagmethod
* @param {Object} o
* @param {Object} event
*/


/**
* 
* @method __modulus
* @static
* @param {Object} x
* @param {Object} y
*/


/**
* 
* @method stacksetsize
* @param {Object} n
*/


/**
* 
* @method stackAdd
* @param {Object} o
*/


/**
* 
* @method pushSlot
* @param {Object} p
*/


/**
* 
* @method stackInsertAt
* @param {Object} o
* @param {Object} i
*/


/**
* 
* @method resethookcount
*/


/**
* 
* @method traceexec
* @param {Object} pc
*/


/**
* 
* @method tonumber
* @static
* @param {Object} o
* @param {Object} out
*/


/**
* 
* @method tonumber
* @param {Object} idx
*/


/**
* 
* @method toNumberPair
* @static
* @param {Object} x
* @param {Object} y
* @param {Object} out
*/


/**
* 
* @method tostring
* @param {Object} idx
*/


/**
* 
* @method tryfuncTM
* @param {Object} func
*/


/**
* 
* @method isFalse
* @param {Object} o
*/


/**
* 
* @method __isFalse
* @param {Object} o
*/


/**
* 
* @method inc_ci
* @param {Object} func
* @param {Object} baseArg
* @param {Object} top
* @param {Object} nresults
*/


/**
* 
* @method dec_ci
*/


/**
* 
* @method resume_error
* @param {Object} msg
*/


/**
* 
* @method objectAt
* @param {Object} idx
*/


/**
* 
* @method setObjectAt
* @param {Object} o
* @param {Object} idx
*/


/**
* 
* @method uDump
* @static
* @param {Object} f
* @param {Object} writer
* @param {Object} strip
*/


/**
* 
* @method getGlobal
*/


/**
* 
* @method setGlobal
* @param {Object} global
*/


/**
* 
* @method setNCcalls
* @param {Object} nCcalls
*/


/**
* 
* @method getNCcalls
*/


/**
* 
* @property _global
* @type Object
*/


/**
* 
* @property _registry
* @type Object
*/


/**
* 
* @property _main
* @type Object
*/


/**
* 
* @property _stack
* @type Object
*/


/**
* 
* @property _stackhighwater
* @type Object
*/


/**
* 
* @property _stackSize
* @type Object
*/


/**
* 
* @property _base
* @type Object
*/


/**
* 
* @property _nCcalls
* @type Object
*/


/**
* 
* @property _savedpc
* @type Object
*/


/**
* 
* @property _civ
* @type Object
*/


/**
* 
* @property _openupval
* @type Object
*/


/**
* 
* @property _hookcount
* @type Object
*/


/**
* 
* @property _basehookcount
* @type Object
*/


/**
* 
* @property _allowhook
* @type Object
*/


/**
* 
* @property _hook
* @type Object
*/


/**
* 
* @property _hookmask
* @type Object
*/


/**
* 
* @property _errfunc
* @type Object
*/


/**
* 
* @property _status
* @type Object
*/


/**
* 
* @property _metatable
* @type Object
*/


/**
* 
* @property _global
* @type Object
*/


/**
* 
* @property _registry
* @type Object
*/


/**
* 
* @property _metatable
* @type Object
*/


/**
* 
* @property _main
* @type Object
*/


/**
* 
* @property _global
* @type Object
*/


/**
* 
* @property _registry
* @type Object
*/


/**
* 
* @property _metatable
* @type Object
*/


/**
* 
* @property _main
* @type Object
*/

