
/**
* 
* @class LocVar
* @constructor 
*/


/**
* 
* @method init
* @param {Object} varname
* @param {Object} startpc
* @param {Object} endpc
*/


/**
* 
* @method getVarname
*/


/**
* 
* @method setVarname
* @param {Object} varname
*/


/**
* 
* @method getStartpc
*/


/**
* 
* @method setStartpc
* @param {Object} startpc
*/


/**
* 
* @method getEndpc
*/


/**
* 
* @method setEndpc
* @param {Object} endpc
*/


/**
* 
* @property _varname
* @type Object
*/


/**
* 
* @property _startpc
* @type Object
*/


/**
* 
* @property _endpc
* @type Object
*/

