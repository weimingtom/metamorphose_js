
/**
* 
* @class SystemUtil
* @constructor 
*/


/**
* 
* @property out
* @type Object
* @final
*/


/**
* 
* @method arraycopy
* @static
* @param {Object} src
* @param {Object} srcPos
* @param {Object} dest
* @param {Object} destPos
* @param {Object} length
*/


/**
* 
* @method gc
* @static
*/


/**
* 
* @method identityHashCode
* @static
* @param {Object} obj
*/


/**
* 
* @method getResourceAsStream
* @static
* @param {Object} s
*/


/**
* 
* @method currentTimeMillis
* @static
*/

