
/**
* 
* @class BlockCnt
* @constructor 
*/

