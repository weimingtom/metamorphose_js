
/**
* 
* @class ByteArrayOutputStream
* @constructor 
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @method toByteArray
*/


/**
* 
* @method close
*/


/**
* 
* @method flush
*/


/**
* 
* @method write
* @param {Object} b
*/


/**
* 
* @method writeBytes
* @param {Object} b
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method writeChar
* @param {Object} b
*/


/**
* 
* @property _bytes
* @type Object
*/

