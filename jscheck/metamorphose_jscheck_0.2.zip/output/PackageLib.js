
/**
* 
* @class PackageLib
* @constructor 
* @param {Object} which
* @param {Object} me
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property MODULE
* @type Object
* @final
*/


/**
* 
* @property REQUIRE
* @type Object
* @final
*/


/**
* 
* @property SEEALL
* @type Object
* @final
*/


/**
* 
* @property LOADER_PRELOAD
* @type Object
* @final
*/


/**
* 
* @property LOADER_LUA
* @type Object
* @final
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method g
* @static
* @param {Object} L
* @param {Object} t
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method p
* @static
* @param {Object} L
* @param {Object} t
* @param {Object} which
*/


/**
* 
* @property DIRSEP
* @type Object
* @final
*/


/**
* 
* @property PATHSEP
* @type Object
* @final
*/


/**
* 
* @property PATH_MARK
* @type Object
* @final
*/


/**
* 
* @property PATH_DEFAULT
* @type Object
* @final
*/


/**
* 
* @property SENTINEL
* @type Object
* @final
*/


/**
* 
* @method loaderPreload
* @param {Object} L
*/


/**
* 
* @method loaderLua
* @param {Object} L
*/


/**
* 
* @method module
* @param {Object} L
*/


/**
* 
* @method require
* @param {Object} L
*/


/**
* 
* @method seeall
* @static
* @param {Object} L
*/


/**
* 
* @method setfenv
* @static
* @param {Object} L
* @param {Object} module
*/


/**
* 
* @method dooptions
* @static
* @param {Object} L
* @param {Object} module
* @param {Object} n
*/


/**
* 
* @method modinit
* @static
* @param {Object} L
* @param {Object} module
* @param {Object} modname
*/


/**
* 
* @method loaderror
* @static
* @param {Object} L
* @param {Object} filename
*/


/**
* 
* @method readable
* @static
* @param {Object} filename
*/


/**
* 
* @method pushnexttemplate
* @static
* @param {Object} L
* @param {Object} path
*/


/**
* 
* @method findfile
* @param {Object} L
* @param {Object} name
* @param {Object} pname
*/


/**
* 
* @method gsub
* @static
* @param {Object} s
* @param {Object} p
* @param {Object} r
*/


/**
* 
* @method setpath
* @static
*/


/**
* 
* @property _which
* @type Object
*/


/**
* 
* @property _me
* @type Object
*/

