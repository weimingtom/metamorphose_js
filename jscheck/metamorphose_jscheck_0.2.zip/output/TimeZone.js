
/**
* 
* @class TimeZone
* @constructor 
*/


/**
* 
* @property tz
* @type Object
* @final
*/


/**
* 
* @property tzGMT
* @type Object
* @final
*/


/**
* 
* @method useDaylightTime
*/


/**
* 
* @method getDefault
* @static
*/


/**
* 
* @method getTimeZone
* @static
* @param {Object} ID
*/


/**
* 
* @method getID
*/


/**
* 
* @property _id
* @type Object
*/

