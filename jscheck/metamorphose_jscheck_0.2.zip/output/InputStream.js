
/**
* 
* @class InputStream
* @constructor 
*/


/**
* 
* @method readBytes
* @param {Object} bytes
*/


/**
* 
* @method read
*/


/**
* 
* @method reset
*/


/**
* 
* @method mark
* @param {Object} i
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method close
*/


/**
* 
* @method available
*/


/**
* 
* @method skip
* @param {Object} n
*/


/**
* 
* @method readMultiBytes
* @param {Object} bytes
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method throwError
* @param {Object} str
*/

