
/**
* 
* @class Debug
* @constructor 
* @param {Object} ici
*/


/**
* 
* @method setIci
* @param {Object} ici
*/


/**
* 
* @method getIci
*/


/**
* 
* @method setEvent
* @param {Object} event
*/


/**
* 
* @method setWhat
* @param {Object} what
*/


/**
* 
* @method setSource
* @param {Object} source
*/


/**
* 
* @method getCurrentline
*/


/**
* 
* @method setCurrentline
* @param {Object} currentline
*/


/**
* 
* @method getLinedefined
*/


/**
* 
* @method setLinedefined
* @param {Object} linedefined
*/


/**
* 
* @method setLastlinedefined
* @param {Object} lastlinedefined
*/


/**
* 
* @method getShortsrc
*/


/**
* 
* @property _ici
* @type Object
*/


/**
* 
* @property _event
* @type Object
*/


/**
* 
* @property _what
* @type Object
*/


/**
* 
* @property _source
* @type Object
*/


/**
* 
* @property _currentline
* @type Object
*/


/**
* 
* @property _linedefined
* @type Object
*/


/**
* 
* @property _lastlinedefined
* @type Object
*/


/**
* 
* @property _shortsrc
* @type Object
*/

