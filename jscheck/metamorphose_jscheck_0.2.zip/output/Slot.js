
/**
* 
* @class Slot
* @constructor 
*/


/**
* 
* @method init1
* @param {Object} s
*/


/**
* 
* @method init2
* @param {Object} o
*/


/**
* 
* @method asObject
*/


/**
* 
* @method setObject
* @param {Object} o
*/


/**
* 
* @method setR
* @param {Object} r
*/


/**
* 
* @method getR
*/


/**
* 
* @method setD
* @param {Object} d
*/


/**
* 
* @method getD
*/


/**
* 
* @property _r
* @type Object
*/


/**
* 
* @property _d
* @type Object
*/

