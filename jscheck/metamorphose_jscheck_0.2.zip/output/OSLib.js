
/**
* 
* @class OSLib
* @constructor 
* @param {Object} which
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property CLOCK
* @type Object
* @final
*/


/**
* 
* @property DATE
* @type Object
* @final
*/


/**
* 
* @property DIFFTIME
* @type Object
* @final
*/


/**
* 
* @property SETLOCALE
* @type Object
* @final
*/


/**
* 
* @property TIME
* @type Object
* @final
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @property T0
* @type Object
* @final
*/


/**
* 
* @method clock
* @static
* @param {Object} L
*/


/**
* 
* @method date
* @static
* @param {Object} L
*/


/**
* 
* @method difftime
* @static
* @param {Object} L
*/


/**
* 
* @property MONTH
* @type Object
* @final
*/


/**
* 
* @method setlocale
* @static
* @param {Object} L
*/


/**
* 
* @method time
* @static
* @param {Object} L
*/


/**
* 
* @method getfield
* @static
* @param {Object} L
* @param {Object} key
* @param {Object} d
*/


/**
* 
* @method setfield
* @static
* @param {Object} L
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method format
* @static
* @param {Object} i
* @param {Object} w
*/


/**
* 
* @method weekdayname
* @static
* @param {Object} c
*/


/**
* 
* @method monthname
* @static
* @param {Object} c
*/


/**
* 
* @method canonicalmonth
* @static
* @param {Object} m
*/


/**
* 
* @property WEEKDAY
* @type Object
* @final
*/


/**
* 
* @method canonicalweekday
* @static
* @param {Object} w
*/


/**
* 
* @property _which
* @type Object
*/

