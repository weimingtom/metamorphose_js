
/**
* 
* @class PrintStream
* @constructor 
*/


/**
* 
* @property OutputArr
* @type Object
* @final
*/


/**
* 
* @method init
* @static
*/


/**
* 
* @method print
* @param {Object} str
*/


/**
* 
* @method println
*/

