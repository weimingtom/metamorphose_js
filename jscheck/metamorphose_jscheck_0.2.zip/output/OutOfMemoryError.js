
/**
* 
* @class OutOfMemoryError
* @constructor 
* @param {Object} str
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property message
* @type Object
*/

