
/**
* 
* @class Proto
* @constructor 
*/


/**
* 
* @property D
* @type Object
* @final
*/


/**
* 
* @property ZERO_INT_ARRAY
* @type Object
* @final
*/


/**
* 
* @property ZERO_LOCVAR_ARRAY
* @type Object
* @final
*/


/**
* 
* @property ZERO_CONSTANT_ARRAY
* @type Object
* @final
*/


/**
* 
* @property ZERO_PROTO_ARRAY
* @type Object
* @final
*/


/**
* 
* @property ZERO_STRING_ARRAY
* @type Object
* @final
*/


/**
* 
* @method init1
*/


/**
* 
* @method init2
* @param {Object} source
* @param {Object} maxstacksize
*/


/**
* 
* @method debug
*/


/**
* 
* @method getSource
*/


/**
* 
* @method setSource
* @param {Object} source
*/


/**
* 
* @method getLinedefined
*/


/**
* 
* @method setLinedefined
* @param {Object} linedefined
*/


/**
* 
* @method getLastlinedefined
*/


/**
* 
* @method setLastlinedefined
* @param {Object} lastlinedefined
*/


/**
* 
* @method getNups
*/


/**
* 
* @method setNups
* @param {Object} nups
*/


/**
* 
* @method getNumparams
*/


/**
* 
* @method setNumparams
* @param {Object} numparams
*/


/**
* 
* @method getMaxstacksize
*/


/**
* 
* @method setMaxstacksize
* @param {Object} m
*/


/**
* 
* @method getCode
*/


/**
* 
* @method codeAppend
* @param {Object} L
* @param {Object} pc
* @param {Object} instruction
* @param {Object} line
*/


/**
* 
* @method ensureLocvars
* @param {Object} L
* @param {Object} atleast
* @param {Object} limit
*/


/**
* 
* @method ensureProtos
* @param {Object} L
* @param {Object} atleast
*/


/**
* 
* @method ensureUpvals
* @param {Object} L
* @param {Object} atleast
*/


/**
* 
* @method ensureCode
* @param {Object} L
* @param {Object} atleast
*/


/**
* 
* @method setLineinfo
* @param {Object} pc
* @param {Object} line
*/


/**
* 
* @method getline
* @param {Object} pc
*/


/**
* 
* @method getProto
*/


/**
* 
* @method getConstant
*/


/**
* 
* @method constantAppend
* @param {Object} idx
* @param {Object} o
*/


/**
* 
* @method getIsVararg
*/


/**
* 
* @method setIsVararg
* @param {Object} isVararg
*/


/**
* 
* @method getLocvars
*/


/**
* 
* @method trimInt
* @param {Object} old
* @param {Object} n
*/


/**
* 
* @method closeCode
* @param {Object} n
*/


/**
* 
* @method closeLineinfo
* @param {Object} n
*/


/**
* 
* @method closeK
* @param {Object} n
*/


/**
* 
* @method closeP
* @param {Object} n
*/


/**
* 
* @method closeLocvars
* @param {Object} n
*/


/**
* 
* @method closeUpvalues
*/


/**
* 
* @method getK
*/


/**
* 
* @method getSizek
*/


/**
* 
* @method getSizecode
*/


/**
* 
* @method getP
*/


/**
* 
* @method getSizep
*/


/**
* 
* @method getLineinfo
*/


/**
* 
* @method getSizelineinfo
*/


/**
* 
* @method getSizelocvars
*/


/**
* 
* @method getUpvalues
*/


/**
* 
* @method getSizeupvalues
*/


/**
* 
* @property _k
* @type Object
*/


/**
* 
* @property _sizek
* @type Object
*/


/**
* 
* @property _code
* @type Object
*/


/**
* 
* @property _sizecode
* @type Object
*/


/**
* 
* @property _p
* @type Object
*/


/**
* 
* @property _sizep
* @type Object
*/


/**
* 
* @property _nups
* @type Object
*/


/**
* 
* @property _numparams
* @type Object
*/


/**
* 
* @property _isVararg
* @type Object
*/


/**
* 
* @property _maxstacksize
* @type Object
*/


/**
* 
* @property _lineinfo
* @type Object
*/


/**
* 
* @property _sizelineinfo
* @type Object
*/


/**
* 
* @property _locvars
* @type Object
*/


/**
* 
* @property _sizelocvars
* @type Object
*/


/**
* 
* @property _upvalues
* @type Object
*/


/**
* 
* @property _sizeupvalues
* @type Object
*/


/**
* 
* @property _source
* @type Object
*/


/**
* 
* @property _linedefined
* @type Object
*/


/**
* 
* @property _lastlinedefined
* @type Object
*/

