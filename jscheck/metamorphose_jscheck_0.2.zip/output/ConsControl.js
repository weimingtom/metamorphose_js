
/**
* 
* @class ConsControl
* @constructor 
* @param {Object} t
*/

