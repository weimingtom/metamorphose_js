package com.iteye.weimingtom.metamorphose.jscheck;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: jscheck [path], now use default path: **input**");
			args = new String[]{"input"};
		}
		
		ArrayList<String> fileNames = new ArrayList<String>();
		ListDir(fileNames, args[0]);
		Map<String, List<MemberInfo>> memberInfoMapAll = new HashMap<String, List<MemberInfo>>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.parse();
			String jsClassName = parser.getJSClassName();
			List<MemberInfo> memberInfoMap = parser.getMemberInfoMap();
			memberInfoMapAll.put(jsClassName, memberInfoMap);
		}
		List<String> outputList = new ArrayList<String>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.validate(memberInfoMapAll, outputList);
		}
		FileUtils.listTofile("jscheck.txt", outputList);
		
		for (Map.Entry<String,List<MemberInfo>> entry : memberInfoMapAll.entrySet()) {
			String staticClassName = entry.getKey();
			List<MemberInfo> staticMemberInfo = entry.getValue();
			List<String> dummyJSContentList = new ArrayList<String>(); 
			for (MemberInfo info : staticMemberInfo) {
				if (info.memberScope.equals("constructor")) {
					MemberInfo constructor = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@class " + constructor.memberName);
					dummyJSContentList.add("* " + "@constructor ");
					if (constructor.listArg.size() > 0) {
						for (String param : constructor.listArg) {
							dummyJSContentList.add("* " + "@param {Object} " + param);
						}
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				} else if (info.memberType.equals("function")) {
					MemberInfo func = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@method " + func.memberName);
					if (func.memberScope.equals("static")) {
						dummyJSContentList.add("* " + "@static");
					}
					if (func.listArg.size() > 0) {
						for (String param : func.listArg) {
							dummyJSContentList.add("* " + "@param {Object} " + param);
						}
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				} else if (info.memberType.equals("var")) {
					MemberInfo varMem = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@property " + varMem.memberName);
					dummyJSContentList.add("* " + "@type Object");
					if (varMem.memberScope.equals("static")) {
						dummyJSContentList.add("* " + "@final");
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				}
			}
			FileUtils.listTofile("output/" + staticClassName + ".js", dummyJSContentList);
		}
	}
	
	private static void ListDir(List<String> fileNames, String dirName) {
		ListFiles(fileNames, new File(dirName));
	}

	private static void ListFiles(List<String> fileNames, File dir) {
		if (dir == null || !dir.exists() || !dir.isDirectory()) {
			return;
		}
		String separator = System.getProperty("file.separator");
		String[] files = dir.list();
		for (int i = 0; i < files.length; i++) {
			File file = new File(dir, files[i]);
			String fileName = dir + separator + file.getName();
			if (file.isFile()) {
				//System.out.println(fileName + "\t" + file.length());
				if (fileName != null && fileName.endsWith(".js")) {
					fileNames.add(fileName);
				}
			} else {
				// System.out.println(fileName + "\t<dir>");
				ListFiles(fileNames, file);
			}
		}
	}
}
