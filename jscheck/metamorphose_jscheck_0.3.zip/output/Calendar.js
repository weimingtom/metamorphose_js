
/**
* 
* @class Calendar
* @module metamorphose
* @constructor 
*/


/**
* 
* @property SECOND
* @type Object
* @final
*/


/**
* 
* @property MINUTE
* @type Object
* @final
*/


/**
* 
* @property HOUR
* @type Object
* @final
*/


/**
* 
* @property DAY_OF_MONTH
* @type Object
* @final
*/


/**
* 
* @property MONTH
* @type Object
* @final
*/


/**
* 
* @property YEAR
* @type Object
* @final
*/


/**
* 
* @property DAY_OF_WEEK
* @type Object
* @final
*/


/**
* 
* @property SUNDAY
* @type Object
* @final
*/


/**
* 
* @property MONDAY
* @type Object
* @final
*/


/**
* 
* @property TUESDAY
* @type Object
* @final
*/


/**
* 
* @property WEDNESDAY
* @type Object
* @final
*/


/**
* 
* @property THURSDAY
* @type Object
* @final
*/


/**
* 
* @property FRIDAY
* @type Object
* @final
*/


/**
* 
* @property SATURDAY
* @type Object
* @final
*/


/**
* 
* @property JANUARY
* @type Object
* @final
*/


/**
* 
* @property FEBRUARY
* @type Object
* @final
*/


/**
* 
* @property MARCH
* @type Object
* @final
*/


/**
* 
* @property APRIL
* @type Object
* @final
*/


/**
* 
* @property MAY
* @type Object
* @final
*/


/**
* 
* @property JUNE
* @type Object
* @final
*/


/**
* 
* @property JULY
* @type Object
* @final
*/


/**
* 
* @property AUGUST
* @type Object
* @final
*/


/**
* 
* @property SEPTEMBER
* @type Object
* @final
*/


/**
* 
* @property OCTOBER
* @type Object
* @final
*/


/**
* 
* @property NOVEMBER
* @type Object
* @final
*/


/**
* 
* @property DECEMBER
* @type Object
* @final
*/


/**
* 
* @property _instance
* @type Object
* @final
*/


/**
* 
* @method _get
* @param {Object} field
*/


/**
* 
* @method _set
* @param {Object} field
* @param {Object} value
*/


/**
* 
* @method getInstance
* @param {Object} t
*/


/**
* 
* @method setTime
* @param {Object} d
*/


/**
* 
* @method getTime
*/


/**
* 
* @property _date
* @type Object
*/

