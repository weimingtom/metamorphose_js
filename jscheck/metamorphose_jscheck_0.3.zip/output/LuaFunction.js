
/**
* 
* @class LuaFunction
* @module metamorphose
* @constructor 
* @param {Object} proto
* @param {Object} upval
* @param {Object} env
*/


/**
* 
* @method upVal
* @param {Object} n
*/


/**
* 
* @method getProto
*/


/**
* 
* @method getEnv
*/


/**
* 
* @method setEnv
* @param {Object} env
*/


/**
* 
* @property _p
* @type Object
*/


/**
* 
* @property _upval
* @type Object
*/


/**
* 
* @property _env
* @type Object
*/

