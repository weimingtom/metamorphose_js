
/**
* 
* @class BlockCnt
* @module metamorphose
* @constructor 
*/

