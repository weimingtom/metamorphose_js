
/**
* 
* @class FromReader
* @module metamorphose
* @constructor 
* @param {Object} reader
*/


/**
* 
* @method mark
* @param {Object} readahead
*/


/**
* 
* @method reset
*/


/**
* 
* @method read
*/


/**
* 
* @property _reader
* @type Object
*/

