
/**
* 
* @class FuncState
* @module metamorphose
* @constructor 
* @param {Object} ls
*/


/**
* 
* @property NO_JUMP
* @type Object
* @final
*/


/**
* 
* @method close
*/


/**
* 
* @method getlocvar
* @param {Object} idx
*/


/**
* 
* @method kCheckstack
* @param {Object} n
*/


/**
* 
* @method kCode
* @param {Object} i
* @param {Object} line
*/


/**
* 
* @method kCodeABC
* @param {Object} o
* @param {Object} a
* @param {Object} b
* @param {Object} c
*/


/**
* 
* @method kCodeABx
* @param {Object} o
* @param {Object} a
* @param {Object} bc
*/


/**
* 
* @method kCodeAsBx
* @param {Object} o
* @param {Object} a
* @param {Object} bc
*/


/**
* 
* @method kDischargevars
* @param {Object} e
*/


/**
* 
* @method kExp2anyreg
* @param {Object} e
*/


/**
* 
* @method kExp2nextreg
* @param {Object} e
*/


/**
* 
* @method kFixline
* @param {Object} line
*/


/**
* 
* @method kInfix
* @param {Object} op
* @param {Object} v
*/


/**
* 
* @method isnumeral
* @param {Object} e
*/


/**
* 
* @method kNil
* @param {Object} from
* @param {Object} n
*/


/**
* 
* @method kNumberK
* @param {Object} r
*/


/**
* 
* @method kPosfix
* @param {Object} op
* @param {Object} e1
* @param {Object} e2
*/


/**
* 
* @method kPrefix
* @param {Object} op
* @param {Object} e
*/


/**
* 
* @method kReserveregs
* @param {Object} n
*/


/**
* 
* @method kRet
* @param {Object} first
* @param {Object} nret
*/


/**
* 
* @method kSetmultret
* @param {Object} e
*/


/**
* 
* @method kSetoneret
* @param {Object} e
*/


/**
* 
* @method kSetreturns
* @param {Object} e
* @param {Object} nresults
*/


/**
* 
* @method kStringK
* @param {Object} s
*/


/**
* 
* @method addk
* @param {Object} o
*/


/**
* 
* @method codearith
* @param {Object} op
* @param {Object} e1
* @param {Object} e2
*/


/**
* 
* @method constfolding
* @param {Object} op
* @param {Object} e1
* @param {Object} e2
*/


/**
* 
* @method codenot
* @param {Object} e
*/


/**
* 
* @method removevalues
* @param {Object} list
*/


/**
* 
* @method dischargejpc
*/


/**
* 
* @method discharge2reg
* @param {Object} e
* @param {Object} reg
*/


/**
* 
* @method exp2reg
* @param {Object} e
* @param {Object} reg
*/


/**
* 
* @method code_label
* @param {Object} a
* @param {Object} b
* @param {Object} jump
*/


/**
* 
* @method need_value
* @param {Object} list
*/


/**
* 
* @method freeexp
* @param {Object} e
*/


/**
* 
* @method setFreereg
* @param {Object} freereg
*/


/**
* 
* @method getFreereg
*/


/**
* 
* @method __freereg
* @param {Object} reg
*/


/**
* 
* @method getcode
* @param {Object} e
*/


/**
* 
* @method setcode
* @param {Object} e
* @param {Object} code
*/


/**
* 
* @method searchvar
* @param {Object} n
*/


/**
* 
* @method setarga
* @param {Object} e
* @param {Object} a
*/


/**
* 
* @method setargb
* @param {Object} e
* @param {Object} b
*/


/**
* 
* @method setargc
* @param {Object} e
* @param {Object} c
*/


/**
* 
* @method kGetlabel
*/


/**
* 
* @method kConcat
* @param {Object} l1
* @param {Object} l2
*/


/**
* 
* @method kPatchlist
* @param {Object} list
* @param {Object} target
*/


/**
* 
* @method patchlistaux
*/


/**
* 
* @method patchtestreg
* @param {Object} node
* @param {Object} reg
*/


/**
* 
* @method getjumpcontrol
* @param {Object} at
*/


/**
* 
* @property OP_ARG_N
* @type Object
* @final
*/


/**
* 
* @property OP_ARG_U
* @type Object
* @final
*/


/**
* 
* @property OP_ARG_R
* @type Object
* @final
*/


/**
* 
* @property OP_ARG_K
* @type Object
* @final
*/


/**
* 
* @property iABC
* @type Object
* @final
*/


/**
* 
* @property iABx
* @type Object
* @final
*/


/**
* 
* @property iAsBx
* @type Object
* @final
*/


/**
* 
* @method opmode
* @static
* @param {Object} t
* @param {Object} a
* @param {Object} b
* @param {Object} c
* @param {Object} m
*/


/**
* 
* @property OPMODE
* @type Object
* @final
*/


/**
* 
* @method getOpMode
* @param {Object} m
*/


/**
* 
* @method testAMode
* @param {Object} m
*/


/**
* 
* @method testTMode
* @param {Object} m
*/


/**
* 
* @method kPatchtohere
* @param {Object} list
*/


/**
* 
* @method fixjump
* @param {Object} at
* @param {Object} dest
*/


/**
* 
* @method getjump
* @param {Object} at
*/


/**
* 
* @method kJump
*/


/**
* 
* @method kStorevar
* @param {Object} _var
* @param {Object} ex
*/


/**
* 
* @method kIndexed
* @param {Object} t
* @param {Object} k
*/


/**
* 
* @method kExp2RK
* @param {Object} e
*/


/**
* 
* @method kExp2val
* @param {Object} e
*/


/**
* 
* @method boolK
* @param {Object} b
*/


/**
* 
* @method nilK
*/


/**
* 
* @method kGoiffalse
* @param {Object} e
*/


/**
* 
* @method kGoiftrue
* @param {Object} e
*/


/**
* 
* @method invertjump
* @param {Object} e
*/


/**
* 
* @method jumponcond
* @param {Object} e
* @param {Object} cond
*/


/**
* 
* @method condjump
* @param {Object} op
* @param {Object} a
* @param {Object} b
* @param {Object} c
*/


/**
* 
* @method discharge2anyreg
* @param {Object} e
*/


/**
* 
* @method kSelf
* @param {Object} e
* @param {Object} key
*/


/**
* 
* @method kSetlist
* @param {Object} base
* @param {Object} nelems
* @param {Object} tostore
*/


/**
* 
* @method codecomp
* @param {Object} op
* @param {Object} cond
* @param {Object} e1
* @param {Object} e2
*/


/**
* 
* @method markupval
* @param {Object} level
*/


/**
* 
* @method getF
*/


/**
* 
* @method setF
* @param {Object} f
*/


/**
* 
* @method getPrev
*/


/**
* 
* @method setPrev
* @param {Object} prev
*/


/**
* 
* @method setLs
* @param {Object} ls
*/


/**
* 
* @method setL
* @param {Object} L
*/


/**
* 
* @method getBl
*/


/**
* 
* @method setBl
* @param {Object} bl
*/


/**
* 
* @method getPc
*/


/**
* 
* @method getNp
*/


/**
* 
* @method setNp
* @param {Object} np
*/


/**
* 
* @method getNlocvars
*/


/**
* 
* @method setNlocvars
* @param {Object} nlocvars
*/


/**
* 
* @method getNactvar
*/


/**
* 
* @method setNactvar
* @param {Object} nactvar
*/


/**
* 
* @method getUpvalues
*/


/**
* 
* @method getActvar
*/


/**
* 
* @property _f
* @type Object
*/


/**
* 
* @property _h
* @type Object
*/


/**
* 
* @property _prev
* @type Object
*/


/**
* 
* @property _ls
* @type Object
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _bl
* @type Object
*/


/**
* 
* @property _pc
* @type Object
*/


/**
* 
* @property _lasttarget
* @type Object
*/


/**
* 
* @property _jpc
* @type Object
*/


/**
* 
* @property _freereg
* @type Object
*/


/**
* 
* @property _nk
* @type Object
*/


/**
* 
* @property _np
* @type Object
*/


/**
* 
* @property _nlocvars
* @type Object
*/


/**
* 
* @property _nactvar
* @type Object
*/


/**
* 
* @property _upvalues
* @type Object
*/


/**
* 
* @property _actvar
* @type Object
*/


/**
* 
* @property _f
* @type Object
*/


/**
* 
* @property _f.init2(ls.source, 2); // default value for maxstacksize
* @type Object
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _ls
* @type Object
*/

