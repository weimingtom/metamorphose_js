
/**
* 
* @class FormatItem
* @module metamorphose
* @constructor 
* @param {Object} L
* @param {Object} s
*/


/**
* 
* @property E_LOWER
* @type Object
* @final
*/


/**
* 
* @property E_UPPER
* @type Object
* @final
*/


/**
* 
* @method getLength
*/


/**
* 
* @method setLength
* @param {Object} length
*/


/**
* 
* @method getType
*/


/**
* 
* @method setType
* @param {Object} type
*/


/**
* 
* @method format
* @param {Object} b
* @param {Object} s
*/


/**
* 
* @method formatChar
* @param {Object} b
* @param {Object} c
*/


/**
* 
* @method formatInteger
* @param {Object} b
* @param {Object} i
*/


/**
* 
* @method formatFloat
* @param {Object} b
* @param {Object} d
*/


/**
* 
* @method formatFloatE
* @param {Object} b
* @param {Object} d
*/


/**
* 
* @method formatFloatRawE
* @param {Object} d
*/


/**
* 
* @method formatFloatF
* @param {Object} b
* @param {Object} d
*/


/**
* 
* @method formatFloatRawF
* @param {Object} d
*/


/**
* 
* @method formatFloatG
* @param {Object} b
* @param {Object} d
*/


/**
* 
* @method formatString
* @param {Object} b
* @param {Object} s
*/


/**
* 
* @method precisionTrim
* @param {Object} t
*/


/**
* 
* @method zeroPad
* @param {Object} t
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _left
* @type Object
*/


/**
* 
* @property _sign
* @type Object
*/


/**
* 
* @property _space
* @type Object
*/


/**
* 
* @property _alt
* @type Object
*/


/**
* 
* @property _zero
* @type Object
*/


/**
* 
* @property _width
* @type Object
*/


/**
* 
* @property _precision
* @type Object
*/


/**
* 
* @property _type
* @type Object
*/


/**
* 
* @property _length
* @type Object
*/


/**
* 
* @property _left
* @type Object
*/


/**
* 
* @property _sign
* @type Object
*/


/**
* 
* @property _space
* @type Object
*/


/**
* 
* @property _alt
* @type Object
*/


/**
* 
* @property _zero
* @type Object
*/


/**
* 
* @property _width
* @type Object
*/


/**
* 
* @property _precision
* @type Object
*/


/**
* 
* @property _type
* @type Object
*/


/**
* 
* @property length
* @type Object
*/

