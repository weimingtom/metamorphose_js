
/**
* 
* @class IllegalArgumentException
* @module metamorphose
* @constructor 
* @param {Object} str
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property message
* @type Object
*/

