
/**
* 
* @class Random
* @module metamorphose
* @constructor 
*/


/**
* 
* @method nextDouble
*/


/**
* 
* @method nextInt
* @param {Object} i
*/


/**
* 
* @method setSeed
* @param {Object} seed
*/

