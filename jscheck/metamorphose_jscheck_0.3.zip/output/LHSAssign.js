
/**
* 
* @class LHSAssign
* @module metamorphose
* @constructor 
*/


/**
* 
* @method init
* @param {Object} prev
*/


/**
* 
* @method getPrev
*/


/**
* 
* @method setPrev
* @param {Object} prev
*/


/**
* 
* @method getV
*/


/**
* 
* @property _prev
* @type Object
*/


/**
* 
* @property _v
* @type Object
*/

