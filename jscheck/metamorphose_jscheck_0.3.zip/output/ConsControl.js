
/**
* 
* @class ConsControl
* @module metamorphose
* @constructor 
* @param {Object} t
*/

