
/**
* 
* @class HashtableEnum
* @module metamorphose
* @constructor 
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/


/**
* 
* @method setArr
* @param {Object} arr
*/


/**
* 
* @property _arr
* @type Object
*/


/**
* 
* @property _idx
* @type Object
*/


/**
* 
* @property _len
* @type Object
*/

