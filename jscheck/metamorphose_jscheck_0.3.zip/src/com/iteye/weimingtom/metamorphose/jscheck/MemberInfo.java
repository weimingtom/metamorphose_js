package com.iteye.weimingtom.metamorphose.jscheck;

import java.util.List;

public class MemberInfo {
	String memberName;
	String memberScope;
	String memberType;
	List<String> listArg; 
}
