﻿module.exports = {
    paths: ['output/'],
    outdir: 'doc/',
	project: {
		name: 'Metamorphose_js',
		description: '<h2>Metamorphose_js</h2> <p>Metamorphose_js</p>',
		version: '0.0.1',
        url: 'https://github.com/weimingtom/metamorphose_js',
        navs: [{
            name: "Home",
            url: "https://github.com/weimingtom/metamorphose_js"
        }, {
            name: "Document",
            url: "https://github.com/weimingtom/metamorphose_js"
        }, {
            name: "About",
            url: "https://github.com/weimingtom/metamorphose_js"
        }]
    },
};
