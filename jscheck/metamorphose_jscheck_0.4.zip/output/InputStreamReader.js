
/**
* 
* @class InputStreamReader
* @module metamorphose
* @constructor 
* @extends Reader
* @param {Object} i
* @param {Object} charsetName
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} readAheadLimit
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method readBytes
* @param {Object} cbuf
*/


/**
* 
* @method readMultiBytes
* @param {Object} cbuf
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method ready
*/


/**
* 
* @method reset
*/


/**
* 
* @method skip
* @param {Object} n
*/


/**
* 
* @property _i
* @type Object
*/


/**
* 
* @property _charsetName
* @type Object
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} readAheadLimit
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method readBytes
* @param {Object} cbuf
*/


/**
* 
* @method readMultiBytes
* @param {Object} cbuf
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method ready
*/


/**
* 
* @method reset
*/


/**
* 
* @method skip
* @param {Object} n
*/


/**
* 
* @method throwError
* @param {Object} str
*/

