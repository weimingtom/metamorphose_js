
/**
* 
* @class Runtime
* @module metamorphose
* @constructor 
*/


/**
* 
* @property _instance
* @type Object
* @final
*/


/**
* 
* @method getRuntime
* @static
*/


/**
* 
* @method totalMemory
*/


/**
* 
* @method freeMemory
*/

