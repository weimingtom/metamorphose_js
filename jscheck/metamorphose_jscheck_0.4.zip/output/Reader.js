
/**
* 
* @class Reader
* @module metamorphose
* @constructor 
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} readAheadLimit
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method readBytes
* @param {Object} cbuf
*/


/**
* 
* @method readMultiBytes
* @param {Object} cbuf
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method ready
*/


/**
* 
* @method reset
*/


/**
* 
* @method skip
* @param {Object} n
*/


/**
* 
* @method throwError
* @param {Object} str
*/

