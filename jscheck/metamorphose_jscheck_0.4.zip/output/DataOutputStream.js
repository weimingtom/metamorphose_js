
/**
* 
* @class DataOutputStream
* @module metamorphose
* @constructor 
* @param {Object} writer
*/


/**
* 
* @method flush
*/


/**
* 
* @method size
*/


/**
* 
* @method write
* @param {Object} b
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method writeBoolean
* @param {Object} v
*/


/**
* 
* @method writeByte
* @param {Object} v
*/


/**
* 
* @method writeBytes
* @param {Object} s
*/


/**
* 
* @method writeChar
* @param {Object} v
*/


/**
* 
* @method writeChars
* @param {Object} s
*/


/**
* 
* @method writeDouble
* @param {Object} v
*/


/**
* 
* @method writeFloat
* @param {Object} v
*/


/**
* 
* @method writeInt
* @param {Object} v
*/


/**
* 
* @method writeLong
* @param {Object} v
*/


/**
* 
* @method writeShort
* @param {Object} v
*/


/**
* 
* @method writeUTF
* @param {Object} str
*/


/**
* 
* @property written
* @type Object
*/


/**
* 
* @property _writer
* @type Object
*/

