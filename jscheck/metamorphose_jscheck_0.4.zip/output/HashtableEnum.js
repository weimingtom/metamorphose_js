
/**
* 
* @class HashtableEnum
* @module metamorphose
* @constructor 
* @extends Enumeration
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/


/**
* 
* @method setArr
* @param {Object} arr
*/


/**
* 
* @property _arr
* @type Object
*/


/**
* 
* @property _idx
* @type Object
*/


/**
* 
* @property _len
* @type Object
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/

