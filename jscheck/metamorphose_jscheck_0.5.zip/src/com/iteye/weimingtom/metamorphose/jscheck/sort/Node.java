package com.iteye.weimingtom.metamorphose.jscheck.sort;

import java.util.HashSet;

public class Node {
	public final String name;
	public final HashSet<Edge> inEdges;
	public final HashSet<Edge> outEdges;

	public Node(String name) {
		this.name = name;
		inEdges = new HashSet<Edge>();
		outEdges = new HashSet<Edge>();
	}

	public Node addEdge(Node node) {
		Edge e = new Edge(this, node);
		outEdges.add(e);
		node.inEdges.add(e);
		return this;
	}

	@Override
	public String toString() {
		return name;
	}

	@Override
	public boolean equals(Object o) {
		return (o instanceof Node)
				&& (((Node) o).toString()).equals(this.toString());
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}
}