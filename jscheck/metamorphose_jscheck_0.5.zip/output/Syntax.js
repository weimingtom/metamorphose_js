
/**
* 
* @class Syntax
* @module metamorphose
* @constructor 
* @param {Object} L
* @param {Object} z
* @param {Object} source
*/


/**
* 
* @property EOZ
* @type Object
* @final
*/


/**
* 
* @property FIRST_RESERVED
* @type Object
* @final
*/


/**
* 
* @property TK_AND
* @type Object
* @final
*/


/**
* 
* @property TK_BREAK
* @type Object
* @final
*/


/**
* 
* @property TK_DO
* @type Object
* @final
*/


/**
* 
* @property TK_ELSE
* @type Object
* @final
*/


/**
* 
* @property TK_ELSEIF
* @type Object
* @final
*/


/**
* 
* @property TK_END
* @type Object
* @final
*/


/**
* 
* @property TK_FALSE
* @type Object
* @final
*/


/**
* 
* @property TK_FOR
* @type Object
* @final
*/


/**
* 
* @property TK_FUNCTION
* @type Object
* @final
*/


/**
* 
* @property TK_IF
* @type Object
* @final
*/


/**
* 
* @property TK_IN
* @type Object
* @final
*/


/**
* 
* @property TK_LOCAL
* @type Object
* @final
*/


/**
* 
* @property TK_NIL
* @type Object
* @final
*/


/**
* 
* @property TK_NOT
* @type Object
* @final
*/


/**
* 
* @property TK_OR
* @type Object
* @final
*/


/**
* 
* @property TK_REPEAT
* @type Object
* @final
*/


/**
* 
* @property TK_RETURN
* @type Object
* @final
*/


/**
* 
* @property TK_THEN
* @type Object
* @final
*/


/**
* 
* @property TK_TRUE
* @type Object
* @final
*/


/**
* 
* @property TK_UNTIL
* @type Object
* @final
*/


/**
* 
* @property TK_WHILE
* @type Object
* @final
*/


/**
* 
* @property TK_CONCAT
* @type Object
* @final
*/


/**
* 
* @property TK_DOTS
* @type Object
* @final
*/


/**
* 
* @property TK_EQ
* @type Object
* @final
*/


/**
* 
* @property TK_GE
* @type Object
* @final
*/


/**
* 
* @property TK_LE
* @type Object
* @final
*/


/**
* 
* @property TK_NE
* @type Object
* @final
*/


/**
* 
* @property TK_NUMBER
* @type Object
* @final
*/


/**
* 
* @property TK_NAME
* @type Object
* @final
*/


/**
* 
* @property TK_STRING
* @type Object
* @final
*/


/**
* 
* @property TK_EOS
* @type Object
* @final
*/


/**
* 
* @property NUM_RESERVED
* @type Object
* @final
*/


/**
* 
* @property _tokens
* @type Object
* @final
*/


/**
* 
* @property _reserved
* @type Object
* @final
*/


/**
* 
* @method init
* @static
*/


/**
* 
* @method getLastline
*/


/**
* 
* @method isalnum
* @static
* @param {Object} c
*/


/**
* 
* @method isalpha
* @static
* @param {Object} c
*/


/**
* 
* @method iscntrl
* @static
* @param {Object} c
*/


/**
* 
* @method isdigit
* @static
* @param {Object} c
*/


/**
* 
* @method islower
* @static
* @param {Object} c
*/


/**
* 
* @method ispunct
* @static
* @param {Object} c
*/


/**
* 
* @method isspace
* @static
* @param {Object} c
*/


/**
* 
* @method isupper
* @static
* @param {Object} c
*/


/**
* 
* @method isxdigit
* @static
* @param {Object} c
*/


/**
* 
* @method check_next
* @param {Object} _set
*/


/**
* 
* @method currIsNewline
*/


/**
* 
* @method inclinenumber
*/


/**
* 
* @method skip_sep
*/


/**
* 
* @method read_long_string
* @param {Object} isString
* @param {Object} sep
*/


/**
* 
* @method llex
*/


/**
* 
* @method next
*/


/**
* 
* @method read_numeral
*/


/**
* 
* @method read_string
* @param {Object} del
*/


/**
* 
* @method save
*/


/**
* 
* @method __save
* @param {Object} c
*/


/**
* 
* @method save_and_next
*/


/**
* 
* @method getSource
*/


/**
* 
* @method txtToken
* @param {Object} tok
*/


/**
* 
* @method xLexerror
* @param {Object} msg
* @param {Object} tok
*/


/**
* 
* @method xNext
*/


/**
* 
* @method xSyntaxerror
* @param {Object} msg
*/


/**
* 
* @method xToken2str
* @static
* @param {Object} token
*/


/**
* 
* @method block_follow
* @static
* @param {Object} token
*/


/**
* 
* @method check
* @param {Object} c
*/


/**
* 
* @method check_match
* @param {Object} what
* @param {Object} who
* @param {Object} where
*/


/**
* 
* @method close_func
*/


/**
* 
* @method opcode_name
* @static
* @param {Object} op
*/


/**
* 
* @method codestring
* @param {Object} e
* @param {Object} s
*/


/**
* 
* @method checkname
* @param {Object} e
*/


/**
* 
* @method enterlevel
*/


/**
* 
* @method error_expected
* @param {Object} tok
*/


/**
* 
* @method leavelevel
*/


/**
* 
* @method parser
* @static
* @param {Object} L
* @param {Object} _in
* @param {Object} name
*/


/**
* 
* @method removevars
* @param {Object} tolevel
*/


/**
* 
* @method singlevar
* @param {Object} _var
*/


/**
* 
* @method singlevaraux
*/


/**
* 
* @method str_checkname
*/


/**
* 
* @method testnext
* @param {Object} c
*/


/**
* 
* @method chunk
*/


/**
* 
* @method constructor
* @param {Object} t
*/


/**
* 
* @method oInt2fb
* @static
* @param {Object} x
*/


/**
* 
* @method recfield
* @param {Object} cc
*/


/**
* 
* @method lastlistfield
* @param {Object} cc
*/


/**
* 
* @method closelistfield
* @param {Object} cc
*/


/**
* 
* @method expr
* @param {Object} v
*/


/**
* 
* @method explist1
* @param {Object} v
*/


/**
* 
* @method exprstat
*/


/**
* 
* @method check_conflict
* @param {Object} lh
* @param {Object} v
*/


/**
* 
* @method assignment
* @param {Object} lh
* @param {Object} nvars
*/


/**
* 
* @method funcargs
* @param {Object} f
*/


/**
* 
* @method prefixexp
* @param {Object} v
*/


/**
* 
* @method primaryexp
* @param {Object} v
*/


/**
* 
* @method retstat
*/


/**
* 
* @method simpleexp
* @param {Object} v
*/


/**
* 
* @method statement
*/


/**
* 
* @property OPR_ADD
* @type Object
* @final
*/


/**
* 
* @property OPR_SUB
* @type Object
* @final
*/


/**
* 
* @property OPR_MUL
* @type Object
* @final
*/


/**
* 
* @property OPR_DIV
* @type Object
* @final
*/


/**
* 
* @property OPR_MOD
* @type Object
* @final
*/


/**
* 
* @property OPR_POW
* @type Object
* @final
*/


/**
* 
* @property OPR_CONCAT
* @type Object
* @final
*/


/**
* 
* @property OPR_NE
* @type Object
* @final
*/


/**
* 
* @property OPR_EQ
* @type Object
* @final
*/


/**
* 
* @property OPR_LT
* @type Object
* @final
*/


/**
* 
* @property OPR_LE
* @type Object
* @final
*/


/**
* 
* @property OPR_GT
* @type Object
* @final
*/


/**
* 
* @property OPR_GE
* @type Object
* @final
*/


/**
* 
* @property OPR_AND
* @type Object
* @final
*/


/**
* 
* @property OPR_OR
* @type Object
* @final
*/


/**
* 
* @property OPR_NOBINOPR
* @type Object
* @final
*/


/**
* 
* @property OPR_MINUS
* @type Object
* @final
*/


/**
* 
* @property OPR_NOT
* @type Object
* @final
*/


/**
* 
* @property OPR_LEN
* @type Object
* @final
*/


/**
* 
* @property OPR_NOUNOPR
* @type Object
* @final
*/


/**
* 
* @method getbinopr
* @static
* @param {Object} op
*/


/**
* 
* @method getunopr
* @static
* @param {Object} op
*/


/**
* 
* @property PRIORITY
* @type Object
* @final
*/


/**
* 
* @property UNARY_PRIORITY
* @type Object
* @final
*/


/**
* 
* @method subexpr
* @param {Object} v
* @param {Object} limit
*/


/**
* 
* @method enterblock
* @param {Object} f
* @param {Object} bl
* @param {Object} isbreakable
*/


/**
* 
* @method leaveblock
* @param {Object} f
*/


/**
* 
* @method block
*/


/**
* 
* @method breakstat
*/


/**
* 
* @method funcstat
* @param {Object} line
*/


/**
* 
* @method checknext
* @param {Object} c
*/


/**
* 
* @method parlist
*/


/**
* 
* @method getlocvar
* @param {Object} i
*/


/**
* 
* @method adjustlocalvars
* @param {Object} nvars
*/


/**
* 
* @method new_localvarliteral
* @param {Object} v
* @param {Object} n
*/


/**
* 
* @method errorlimit
* @param {Object} limit
* @param {Object} what
*/


/**
* 
* @method yChecklimit
* @param {Object} v
* @param {Object} l
* @param {Object} m
*/


/**
* 
* @method new_localvar
* @param {Object} name
* @param {Object} n
*/


/**
* 
* @method registerlocalvar
* @param {Object} varname
*/


/**
* 
* @method body
* @param {Object} e
* @param {Object} needself
* @param {Object} line
*/


/**
* 
* @method UPVAL_K
* @param {Object} upvaldesc
*/


/**
* 
* @method UPVAL_INFO
* @param {Object} upvaldesc
*/


/**
* 
* @method UPVAL_ENCODE
* @param {Object} k
* @param {Object} info
*/


/**
* 
* @method pushclosure
* @param {Object} func
* @param {Object} v
*/


/**
* 
* @method funcname
* @param {Object} v
*/


/**
* 
* @method field
* @param {Object} v
*/


/**
* 
* @method repeatstat
* @param {Object} line
*/


/**
* 
* @method cond
*/


/**
* 
* @method open_func
* @param {Object} funcstate
*/


/**
* 
* @method localstat
*/


/**
* 
* @method forstat
* @param {Object} line
*/


/**
* 
* @method fornum
* @param {Object} varname
* @param {Object} line
*/


/**
* 
* @method exp1
*/


/**
* 
* @method forlist
* @param {Object} indexname
*/


/**
* 
* @method forbody
* @param {Object} base
* @param {Object} line
* @param {Object} nvars
* @param {Object} isnum
*/


/**
* 
* @method ifstat
* @param {Object} line
*/


/**
* 
* @method test_then_block
*/


/**
* 
* @method whilestat
* @param {Object} line
*/


/**
* 
* @method hasmultret
* @static
* @param {Object} k
*/


/**
* 
* @method adjust_assign
* @param {Object} nvars
* @param {Object} nexps
* @param {Object} e
*/


/**
* 
* @method localfunc
*/


/**
* 
* @method yindex
* @param {Object} v
*/


/**
* 
* @method xLookahead
*/


/**
* 
* @method listfield
* @param {Object} cc
*/


/**
* 
* @method indexupvalue
* @param {Object} funcstate
* @param {Object} name
* @param {Object} v
*/


/**
* 
* @method getL
*/


/**
* 
* @property _current
* @type Object
*/


/**
* 
* @property _linenumber
* @type Object
*/


/**
* 
* @property _lastline
* @type Object
*/


/**
* 
* @property _token
* @type Object
*/


/**
* 
* @property _tokenR
* @type Object
*/


/**
* 
* @property _tokenS
* @type Object
*/


/**
* 
* @property _lookahead
* @type Object
*/


/**
* 
* @property _lookaheadR
* @type Object
*/


/**
* 
* @property _lookaheadS
* @type Object
*/


/**
* 
* @property _semR
* @type Object
*/


/**
* 
* @property _semS
* @type Object
*/


/**
* 
* @property _fs
* @type Object
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _z
* @type Object
*/


/**
* 
* @property _buff
* @type Object
*/


/**
* 
* @property _source
* @type Object
*/


/**
* 
* @property _decpoint
* @type Object
*/


/**
* 
* @property _L
* @type Object
*/


/**
* 
* @property _z
* @type Object
*/


/**
* 
* @property _source
* @type Object
*/

