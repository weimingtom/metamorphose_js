
/**
* 
* @class BaseLib
* @module metamorphose
* @constructor 
* @extends LuaJavaCallback
* @param {Object} which
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property ASSERT
* @type Object
* @final
*/


/**
* 
* @property COLLECTGARBAGE
* @type Object
* @final
*/


/**
* 
* @property DOFILE
* @type Object
* @final
*/


/**
* 
* @property ERROR
* @type Object
* @final
*/


/**
* 
* @property GETFENV
* @type Object
* @final
*/


/**
* 
* @property GETMETATABLE
* @type Object
* @final
*/


/**
* 
* @property LOADFILE
* @type Object
* @final
*/


/**
* 
* @property LOAD
* @type Object
* @final
*/


/**
* 
* @property LOADSTRING
* @type Object
* @final
*/


/**
* 
* @property NEXT
* @type Object
* @final
*/


/**
* 
* @property PCALL
* @type Object
* @final
*/


/**
* 
* @property PRINT
* @type Object
* @final
*/


/**
* 
* @property RAWEQUAL
* @type Object
* @final
*/


/**
* 
* @property RAWGET
* @type Object
* @final
*/


/**
* 
* @property RAWSET
* @type Object
* @final
*/


/**
* 
* @property SELECT
* @type Object
* @final
*/


/**
* 
* @property SETFENV
* @type Object
* @final
*/


/**
* 
* @property SETMETATABLE
* @type Object
* @final
*/


/**
* 
* @property TONUMBER
* @type Object
* @final
*/


/**
* 
* @property TOSTRING
* @type Object
* @final
*/


/**
* 
* @property TYPE
* @type Object
* @final
*/


/**
* 
* @property UNPACK
* @type Object
* @final
*/


/**
* 
* @property XPCALL
* @type Object
* @final
*/


/**
* 
* @property IPAIRS
* @type Object
* @final
*/


/**
* 
* @property PAIRS
* @type Object
* @final
*/


/**
* 
* @property IPAIRS_AUX
* @type Object
* @final
*/


/**
* 
* @property PAIRS_AUX
* @type Object
* @final
*/


/**
* 
* @property CREATE
* @type Object
* @final
*/


/**
* 
* @property RESUME
* @type Object
* @final
*/


/**
* 
* @property RUNNING
* @type Object
* @final
*/


/**
* 
* @property STATUS
* @type Object
* @final
*/


/**
* 
* @property WRAP
* @type Object
* @final
*/


/**
* 
* @property YIELD
* @type Object
* @final
*/


/**
* 
* @property WRAP_AUX
* @type Object
* @final
*/


/**
* 
* @property IPAIRS_AUX_FUN
* @type Object
* @final
*/


/**
* 
* @property PAIRS_AUX_FUN
* @type Object
* @final
*/


/**
* 
* @method init
* @param {Object} L
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method c
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method assertFunction
* @static
* @param {Object} L
*/


/**
* 
* @property CGOPTS
* @type Object
* @final
*/


/**
* 
* @property CGOPTSNUM
* @type Object
* @final
*/


/**
* 
* @method collectgarbage
* @static
* @param {Object} L
*/


/**
* 
* @method dofile
* @static
* @param {Object} L
*/


/**
* 
* @method error
* @static
* @param {Object} L
*/


/**
* 
* @method getfunc
* @static
* @param {Object} L
*/


/**
* 
* @method getfenv
* @static
* @param {Object} L
*/


/**
* 
* @method getmetatable
* @static
* @param {Object} L
*/


/**
* 
* @method load
* @static
* @param {Object} L
*/


/**
* 
* @method loadfile
* @static
* @param {Object} L
*/


/**
* 
* @method loadstring
* @static
* @param {Object} L
*/


/**
* 
* @method load_aux
* @static
* @param {Object} L
* @param {Object} status
*/


/**
* 
* @method next
* @static
* @param {Object} L
*/


/**
* 
* @method ipairs
* @static
* @param {Object} L
*/


/**
* 
* @method ipairsaux
* @static
* @param {Object} L
*/


/**
* 
* @method pairs
* @static
* @param {Object} L
*/


/**
* 
* @method pairsaux
* @static
* @param {Object} L
*/


/**
* 
* @method pcall
* @static
* @param {Object} L
*/


/**
* 
* @property OUT
* @type Object
* @final
*/


/**
* 
* @method print
* @static
* @param {Object} L
*/


/**
* 
* @method rawequal
* @static
* @param {Object} L
*/


/**
* 
* @method rawget
* @static
* @param {Object} L
*/


/**
* 
* @method rawset
* @static
* @param {Object} L
*/


/**
* 
* @method select
* @static
* @param {Object} L
*/


/**
* 
* @method setfenv
* @static
* @param {Object} L
*/


/**
* 
* @method setmetatable
* @static
* @param {Object} L
*/


/**
* 
* @method tonumber
* @static
* @param {Object} L
*/


/**
* 
* @method tostring
* @static
* @param {Object} L
*/


/**
* 
* @method type
* @static
* @param {Object} L
*/


/**
* 
* @method unpack
* @static
* @param {Object} L
*/


/**
* 
* @method xpcall
* @static
* @param {Object} L
*/


/**
* 
* @method create
* @static
* @param {Object} L
*/


/**
* 
* @method resume
* @static
* @param {Object} L
*/


/**
* 
* @method running
* @static
* @param {Object} L
*/


/**
* 
* @method status
* @static
* @param {Object} L
*/


/**
* 
* @method wrap
* @static
* @param {Object} L
*/


/**
* 
* @method wrapit
* @static
* @param {Object} L
*/


/**
* 
* @method wrapaux
* @param {Object} L
*/


/**
* 
* @method auxresume
* @static
* @param {Object} L
* @param {Object} co
* @param {Object} narg
*/


/**
* 
* @method yield
* @static
* @param {Object} L
*/


/**
* 
* @property which
* @type Object
*/


/**
* 
* @property thread
* @type Object
*/

