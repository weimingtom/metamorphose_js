
/**
* 
* @class Hook
* @module metamorphose
* @constructor 
*/


/**
* 
* @method luaHook
* @param {Object} L
* @param {Object} ar
*/

