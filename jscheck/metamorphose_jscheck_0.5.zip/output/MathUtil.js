
/**
* 
* @class MathUtil
* @module metamorphose
* @constructor 
*/


/**
* 
* @method toDegrees
* @static
* @param {Object} rad
*/


/**
* 
* @method toRadians
* @static
* @param {Object} deg
*/

