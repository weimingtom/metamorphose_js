
/**
* 
* @class Loader
* @module metamorphose
* @constructor 
* @param {Object} _in
* @param {Object} name
*/


/**
* 
* @method undump
*/


/**
* 
* @method block
* @param {Object} b
*/


/**
* 
* @method byteLoad
*/


/**
* 
* @method code
*/


/**
* 
* @method constant
*/


/**
* 
* @method debug
* @param {Object} proto
*/


/**
* 
* @method _function
* @param {Object} parentSource
*/


/**
* 
* @property HEADERSIZE
* @type Object
* @final
*/


/**
* 
* @property HEADER
* @type Object
* @final
*/


/**
* 
* @method header
*/


/**
* 
* @method intLoad
*/


/**
* 
* @method number
*/


/**
* 
* @method proto
* @param {Object} source
*/


/**
* 
* @method string
*/


/**
* 
* @method arrayEquals
* @static
* @param {Object} x
* @param {Object} y
*/


/**
* 
* @property _bigendian
* @type Object
*/


/**
* 
* @property _intbuf
* @type Object
*/


/**
* 
* @property _longbuf
* @type Object
*/


/**
* 
* @property _in
* @type Object
*/


/**
* 
* @property _name
* @type Object
*/


/**
* 
* @property _name
* @type Object
*/


/**
* 
* @property _name
* @type Object
*/

