
/**
* 
* @class StringBuffer
* @module metamorphose
* @constructor 
* @param {Object} str
*/


/**
* 
* @method init
* @param {Object} i
*/


/**
* 
* @method setLength
* @param {Object} i
*/


/**
* 
* @method toString
*/


/**
* 
* @method append
* @param {Object} ch
*/


/**
* 
* @method appendStringBuffer
* @param {Object} buf
*/


/**
* 
* @method appendString
* @param {Object} str
*/


/**
* 
* @method _delete
* @param {Object} start
* @param {Object} end
*/


/**
* 
* @method insert
* @param {Object} at
* @param {Object} ch
*/


/**
* 
* @method insertStringBuffer
* @param {Object} at
* @param {Object} buf
*/


/**
* 
* @method length
*/


/**
* 
* @method charAt
* @param {Object} index
*/


/**
* 
* @method deleteCharAt
* @param {Object} index
*/


/**
* 
* @property _str
* @type Object
*/

