
/**
* 
* @class BlockCnt
* @module metamorphose
* @constructor 
*/


/**
* 
* @property previous
* @type Object
*/


/**
* 
* @property breaklist
* @type Object
*/


/**
* 
* @property nactvar
* @type Object
*/


/**
* 
* @property upval
* @type Object
*/


/**
* 
* @property isbreakable
* @type Object
*/

