
/**
* 
* @class LuaTable
* @module metamorphose
* @constructor 
* @extends Hashtable
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property MAXBITS
* @type Object
* @final
*/


/**
* 
* @property MAXASIZE
* @type Object
* @final
*/


/**
* 
* @property ZERO
* @type Object
* @final
*/


/**
* 
* @method init
* @param {Object} narray
* @param {Object} nhash
*/


/**
* 
* @method equals
* @param {Object} o
*/


/**
* 
* @method hashCode
*/


/**
* 
* @method arrayindex
* @static
* @param {Object} key
*/


/**
* 
* @method computesizes
* @static
* @param {Object} nums
* @param {Object} narray
*/


/**
* 
* @method countint
* @param {Object} key
* @param {Object} nums
*/


/**
* 
* @method numusearray
* @param {Object} nums
*/


/**
* 
* @method numusehash
* @param {Object} nums
* @param {Object} pnasize
*/


/**
* 
* @method resize
* @param {Object} nasize
*/


/**
* 
* @method rehash
*/


/**
* 
* @method getMetatable
*/


/**
* 
* @method setMetatable
* @param {Object} metatable
*/


/**
* 
* @method getn
*/


/**
* 
* @method getlua
* @param {Object} key
*/


/**
* 
* @method __getlua
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method getnum
* @param {Object} k
*/


/**
* 
* @method putluaObj
* @param {Object} L
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method putluaSlot
* @param {Object} L
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method putnum
* @param {Object} k
* @param {Object} v
*/


/**
* 
* @method _get
* @param {Object} key
*/


/**
* 
* @method keys
*/


/**
* 
* @method put
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @property LOG2
* @type Object
* @final
*/


/**
* 
* @method oLog2
* @static
* @param {Object} x
*/


/**
* 
* @method ceillog2
* @static
* @param {Object} x
*/


/**
* 
* @method getArray
*/


/**
* 
* @method getSizeArray
*/


/**
* 
* @property _array
* @type Object
*/


/**
* 
* @property _sizeArray
* @type Object
*/


/**
* 
* @property _inrehash
* @type Object
*/


/**
* 
* @property _metatable
* @type Object
*/


/**
* 
* @method rehash
*/


/**
* 
* @method keys
*/


/**
* 
* @method _get
* @param {Object} key
*/


/**
* 
* @method put
* @param {Object} key
* @param {Object} value
*/


/**
* 
* @method remove
* @param {Object} key
*/


/**
* 
* @property _dic
* @type Object
*/

