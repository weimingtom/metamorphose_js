
/**
* 
* @class Enum
* @module metamorphose
* @constructor 
* @param {Object} t
* @param {Object} e
*/


/**
* 
* @method inci
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/


/**
* 
* @property _t
* @type Object
*/


/**
* 
* @property _i
* @type Object
*/


/**
* 
* @property _e
* @type Object
*/

