
/**
* 
* @class TableLib
* @module metamorphose
* @constructor 
* @param {Object} which
*/


/**
* 
* @property CONCAT
* @type Object
* @final
*/


/**
* 
* @property INSERT
* @type Object
* @final
*/


/**
* 
* @property MAXN
* @type Object
* @final
*/


/**
* 
* @property REMOVE
* @type Object
* @final
*/


/**
* 
* @property SORT
* @type Object
* @final
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method concat
* @static
* @param {Object} L
*/


/**
* 
* @method insert
* @static
* @param {Object} L
*/


/**
* 
* @method maxn
* @static
* @param {Object} L
*/


/**
* 
* @method remove
* @static
* @param {Object} L
*/


/**
* 
* @method sort
* @static
* @param {Object} L
*/


/**
* 
* @method auxsort
* @static
* @param {Object} L
* @param {Object} l
* @param {Object} u
*/


/**
* 
* @method sort_comp
* @static
* @param {Object} L
* @param {Object} a
* @param {Object} b
*/


/**
* 
* @method aux_getn
* @static
* @param {Object} L
* @param {Object} n
*/


/**
* 
* @property _which
* @type Object
*/

