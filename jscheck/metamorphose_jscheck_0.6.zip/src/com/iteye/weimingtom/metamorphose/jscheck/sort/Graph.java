package com.iteye.weimingtom.metamorphose.jscheck.sort;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Find dependency files in order
 * 
 * @author Fei
 * @see https://github.com/dongfeiwww/printDependency
 */
public class Graph {
	public static boolean topologicalSort(List<List<String>> inputs, List<String> outputs, Map<String, List<String>> outputLoop) {
		Map<String, Node> allNodesMap;
		allNodesMap = new HashMap<String, Node>();
		buildGraph(allNodesMap, inputs);

		// noDepentSet <- Set of all nodes with no incoming edges
		Set<Node> noDepentSet = new HashSet<Node>();
		for (Node n : allNodesMap.values()) {
			if (n.inEdges.size() == 0) {
				noDepentSet.add(n);
			}
		}

		// while noDepentSet is non-empty do
		while (!noDepentSet.isEmpty()) {
			// remove a node n from noDepentSet
			Node n = noDepentSet.iterator().next();
			noDepentSet.remove(n);
			// add candidate into final output list
			if (outputs != null) {
				outputs.add(n.toString());
			}

			// for each node m with an edge e from n to m do
			for (Iterator<Edge> it = n.outEdges.iterator(); it.hasNext();) {
				// remove edge e from the graph
				Edge e = it.next();
				Node m = e.to;
				it.remove(); // Remove edge from n
				m.inEdges.remove(e); // Remove edge from m

				// if m has no other incoming edges then insert m into S
				if (m.inEdges.isEmpty()) {
					noDepentSet.add(m);
				}
			}
		}

		// Check to see if all edges are removed
		boolean cycle = false;
		for (Node n : allNodesMap.values()) {
			if (!n.inEdges.isEmpty()) {
				cycle = true;
				break;
			}
		}

		if (cycle) {
			if (outputLoop != null) {
				for (Node n : allNodesMap.values()) {
					if (!n.inEdges.isEmpty()) {
						List<String> inEdgesList = new ArrayList<String>();
						for (Edge edge : n.inEdges) {
							inEdgesList.add(edge.from.name);
						}
						outputLoop.put(n.name, inEdgesList);
					}
				}
			}
			return false;
		} else {
			return true;
		}
	}

	private static void buildGraph(Map<String, Node> allNodesMap, List<List<String>> inputs) {
		for (List<String> tokens : inputs) {
			if (tokens.size() > 0) {
				String fromName = tokens.get(0);
				if (!allNodesMap.containsKey(fromName))
					allNodesMap.put(fromName, new Node(fromName));
				Node from = allNodesMap.get(fromName);
				for (int i = 1; i < tokens.size(); i++) {
					String toName = tokens.get(i);
					if (!allNodesMap.containsKey(toName))
						allNodesMap.put(toName, new Node(toName));
					Node to = allNodesMap.get(toName);
					from.addEdge(to);
				}
			}
		}
	}
}
