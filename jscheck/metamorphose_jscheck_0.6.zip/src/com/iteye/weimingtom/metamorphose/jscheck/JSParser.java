package com.iteye.weimingtom.metamorphose.jscheck;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JSParser {
	private String mFilename;
	private List<MemberInfo> memberInfoMap = new ArrayList<MemberInfo>();
	private String className = "";
	
	public JSParser(String filename) {
		this.mFilename = filename;
	}
	
	public String getJSClassName() {
		return className;
	}
	
	public List<MemberInfo> getMemberInfoMap() {
		return memberInfoMap;
	}
	
	public void parse() {
		System.out.println("========================>parse start:" + mFilename);
		File file = new File(mFilename);
		String name = file.getName();
		System.out.println("name = " + name);
		int index = name.indexOf(".");
		if (index >= 0) {
			className = name.substring(0, index);
		}
		System.out.println("className=" + className);
		if (className.length() == 0) {
			throw new RuntimeException("moduleName empty");
		}
		List<String> content = FileUtils.fileToList(mFilename);
		System.out.println("content.size=" + content.size());
		
		int linenoConstructorStart = 0;
		int linenoConstructorEnd = 0;
		MemberInfo consructorInfo = null;
		for (int lineno = 1; lineno <= content.size(); lineno++) {
			String line = content.get(lineno - 1);
			if (line.startsWith("var ") && line.contains(className) && line.contains("=") && line.contains("function")) {
				linenoConstructorStart = lineno;
				System.out.println(">>constructor,function[" + className + "](" + mFilename + ":" + lineno + ") : " + line);
				List<String> listArg = new ArrayList<String>();
				String strArgList = "";
				String line3 = line.replaceAll("/\\*.*?\\*/", "");
				int index31 = line3.lastIndexOf("(");
				int index32 = line3.lastIndexOf(")");
				if (index31 >= 0 && index32 >= 0 && index31 < index32) {
					strArgList = line3.substring(index31+1, index32);
				}
				String[] arrArg = strArgList.split(",");
				for (String arg : arrArg) {
					String argStr = arg.trim();
					if (argStr.length() > 0) {
						listArg.add(argStr);
					}
				}
				System.out.println(">>>>listArg=" + listArg.toString());
				consructorInfo = addMemberInfo(className, "constructor", "function", listArg);
			} else if (line.contains(".prototype") && 
					line.contains("=") &&
					line.contains("new") && !line.contains("function")) {
				//base class
				Pattern pattern;
				Matcher matcher;
				pattern = Pattern.compile("new\\s+(\\w+)", Pattern.MULTILINE);
				matcher = pattern.matcher(line);
				String baseClassName = "";
				if (matcher.find()) {
					baseClassName = matcher.group(1);
				}
				if (consructorInfo != null) {
					consructorInfo.baseClassName = baseClassName;
				}
			}
		}
		for (int lineno = 1; lineno <= content.size(); lineno++) {
			String line = content.get(lineno - 1);
			if (line.startsWith(className + ".") && line.contains("=")) {
				if (linenoConstructorEnd == 0) {
					linenoConstructorEnd = lineno;
				}
				
				//System.out.println(">member loc (" + lineno + ") : " + line);
				
				String memberScope = "";
				String memberName = "";
				String memberType = "";
				if (line.startsWith(className + ".prototype.")) {
					memberScope = "this";
					String line2 = line.substring((className + ".prototype.").length());
					//System.out.println("line2 =" + line2);
					int index21 = line2.indexOf(" ");
					int index22 = line2.indexOf("=");
					int index2 = -1;
					if (index21 >= 0) {
						index2 = index21;
					}
					if (index22 >= 0 && index22 < index2) {
						index2 = index22;
					}
					if (index2 >= 0) {
						memberName = line2.substring(0, index2);
					}
				} else if (line.startsWith(className + ".")) {
					memberScope = "static";
					//System.out.println(">>static  (" + lineno + ") : " + line);
					String line2 = line.substring((className + ".").length());
					//System.out.println("line2 =" + line2);
					int index21 = line2.indexOf(" ");
					int index22 = line2.indexOf("=");
					int index2 = -1;
					if (index21 >= 0) {
						index2 = index21;
					}
					if (index22 >= 0 && index22 < index2) {
						index2 = index22;
					}
					if (index2 >= 0) {
						memberName = line2.substring(0, index2);
					}
				}
				if (line.contains(" function")) {
					memberType = "function";
				} else {
					memberType = "var";
				}
				List<String> listArg = new ArrayList<String>();
				if (memberType.equals("function")) {
					String strArgList = "";
					String line3 = line.replaceAll("/\\*.*?\\*/", "");
					int index31 = line3.lastIndexOf("(");
					int index32 = line3.lastIndexOf(")");
					if (index31 >= 0 && index32 >= 0 && index31 < index32) {
						strArgList = line3.substring(index31+1, index32);
					}
					String[] arrArg = strArgList.split(",");
					for (String arg : arrArg) {
						String argStr = arg.trim();
						if (argStr.length() > 0) {
							listArg.add(argStr);
						}
					}
				}
				
				if (memberName.length() > 0) {
					System.out.println(">>" + memberScope + "," + memberType + "[" + memberName + "](" + mFilename + ":" + lineno + ") : " + line);
					if (memberType.equals("function")) {
						System.out.println(">>>>listArg=" + listArg.toString());
					}
					addMemberInfo(memberName, memberScope, memberType, listArg);
				} else {
					new Exception("memberName empty").printStackTrace();
				}
			}
		}
		if (linenoConstructorStart > 0 && linenoConstructorEnd > 0 &&
			linenoConstructorStart < linenoConstructorEnd) {
			//good
		} else if (linenoConstructorStart > 0 && linenoConstructorEnd == 0) {
			linenoConstructorEnd = content.size();
			//to end of file
		} else {
			System.out.println("constructor not found");
		}
		
		for (int lineno = 1; lineno <= content.size(); lineno++) {
			String line = content.get(lineno - 1);
			if (lineno > linenoConstructorStart && lineno < linenoConstructorEnd) {
				line = line.trim();
				if (line.startsWith("this.") && line.contains("=")) {
					int index41 = line.indexOf("this.");
					int index42 = line.indexOf("=");
					if (index41 >= 0 && index42 >= 0 && index41 + "this.".length() < index42 - 1) {
						index41 += "this.".length();
						String memberName = line.substring(index41, index42);
						memberName = memberName.trim();
						String memberScope = "this";
						String memberType = "var";
						if (memberName.length() > 0) {
							System.out.println(">>" + memberScope + "," + memberType + "[" + memberName + "](" + mFilename + ":" + lineno + ") : " + line);
							addMemberInfo(memberName, memberScope, memberType, null);
						} else {
							new Exception("memberName empty").printStackTrace();
						}
					}
				}
			}
		}
		
		System.out.println("========================>parse end:" + mFilename);
	}
	
	private MemberInfo addMemberInfo(String memberName, String memberScope, String memberType, List<String> listArg) {
		MemberInfo info = new MemberInfo();
		info.memberName = memberName;
		info.memberScope = memberScope;
		info.memberType = memberType;
		info.listArg = new ArrayList<String>();
		if (listArg != null) {
			info.listArg.addAll(listArg);
		}
		boolean found = false;
		for (MemberInfo infoSearch : memberInfoMap) {
			if (infoSearch.memberName.equals(memberName)) {
				found = true;
				break;
			}
		}
		if (found) {
			if (info.memberScope.equals("this") && info.memberType.equals("var")) {
				//ignore
			} else {
				new Exception("memberName exists!!!").printStackTrace();
			}
		}
		memberInfoMap.add(info);
		return info;
	}
	
	public void validate(Map<String, List<MemberInfo>> memberInfoMapAll, List<String> outputList) {
		System.out.println("========================>validate start:" + mFilename);
		File file = new File(mFilename);
		String name = file.getName();
		System.out.println("name = " + name);
		int index = name.indexOf(".");
		if (index >= 0) {
			className = name.substring(0, index);
		}
		System.out.println("className=" + className);
		if (className.length() == 0) {
			throw new RuntimeException("moduleName empty");
		}
		List<String> content = FileUtils.fileToList(mFilename);
		System.out.println("content.size=" + content.size());
		System.out.println("========================>validate end:" + mFilename);
		
		List<MemberInfo> thisMemberInfo = memberInfoMapAll.get(className);
		if (thisMemberInfo == null) {
			thisMemberInfo = new ArrayList<MemberInfo>();
		}
		List<MemberInfo> endMemberInfo = thisMemberInfo;
		while (true) {
			boolean noBaseClass = true;
			
			for (MemberInfo member : endMemberInfo) {
				if (member.memberScope.equals("constructor")) {
					if (member.baseClassName != null && 
							member.baseClassName.length() > 0) {
						endMemberInfo = memberInfoMapAll.get(member.baseClassName);
						if (endMemberInfo != null) {
							noBaseClass = false;
							break;
						}
					}
				}
			}
			if (noBaseClass == false) {
				for (MemberInfo member2 : endMemberInfo) {
					if (member2.memberScope.equals("this")) {
						thisMemberInfo.add(member2); //fill base class member to subclass
					}
				}
			} else {
				break;
			}
		}
		for (int lineno = 1; lineno <= content.size(); lineno++) {
			String line = content.get(lineno - 1);
			if (!validateLine(line)) {
				continue;
			}
			String lineScan = line.replaceAll("/\\*.*?\\*/", "");
			lineScan = lineScan.replaceAll("\\\".*?\\\"", ""); //not greedy
			lineScan = lineScan.replaceAll("\\\'.*?\\\'", ""); //not greedy
			Pattern pattern;
			Matcher matcher;
			pattern = Pattern.compile("(\\w*)" + "this\\.(\\w+)", Pattern.MULTILINE);
			matcher = pattern.matcher(lineScan);
			while (matcher.find()) {
				String prefix = matcher.group(1);
				String memberName = matcher.group(2);
				if (prefix.length() > 0) {
					continue;
				}
				//System.out.println(">>>>>>>>>>>>>>>>>>>>origin:" + line);
				//System.out.println(">>>>>>>>>>>>>>>>>>>>" + memberName);
				//validate this var or this function
				boolean found = false;
				for (MemberInfo mem : thisMemberInfo) { //FIXME:not account for base class
					if (mem.memberScope.equals("this") && mem.memberName.equals(memberName)) {
						found = true;
					}
				}
				if (found == false) {
					String warning = "<<" + "this.memberName not found" + "[" + memberName + "](" + mFilename + ":" + lineno + ") : " + line;
					System.out.println(warning);
					outputList.add(warning);
				}
			}
			
			for (Map.Entry<String,List<MemberInfo>> entry : memberInfoMapAll.entrySet()) {
				String staticClassName = entry.getKey();
				List<MemberInfo> staticMemberInfo = entry.getValue();
				
				pattern = Pattern.compile("(\\w*)" + staticClassName + "\\.(\\w+)", Pattern.MULTILINE);
				matcher = pattern.matcher(lineScan);
				while (matcher.find()) {
					String prefix = matcher.group(1);
					String memberName = matcher.group(2);
					if (prefix.length() > 0) {
						continue;
					}
					if (memberName.equals("prototype")) {
						continue;
					}
					if (memberName.equals("js") && (lineScan.contains(".js\"") || lineScan.contains(".js\'"))) {
						continue;
					}
					//System.out.println(">>>>>>>>>>>>>>>>>>>>origin:" + line);
					//System.out.println(">>>>>>>>>>>>>>>>>>>>" + memberName);
					//validate this var or this function
					boolean found = false;
					for (MemberInfo mem : staticMemberInfo) {
						if (mem.memberScope.equals("static") && mem.memberName.equals(memberName)) {
							found = true;
						}
					}
					if (found == false) {
						String warning = "<<" + "static.memberName not found" + "[" + memberName + "](" + mFilename + ":" + lineno + ") : " + line;
						System.out.println(warning);
						outputList.add(warning);
					}
				}
			}
		}
		System.out.println("========================>validate end:" + mFilename);
	}
	
	private static boolean validateLine(String line) {
		String strLine = line.trim();
		if (strLine.startsWith("/*")) {
			return false;
		}
		if (strLine.startsWith("*")) {
			return false;
		}
		if (strLine.startsWith("//")) {
			return false;
		}
		return true;
	}
	
	public static void test() {
		String line = "\"xxx\" and \"xxx\"";
		String lineScan = line.replaceAll("/\\*.*?\\*/", "");
		if (lineScan.contains("\"") && lineScan.contains("'")) {
			//not able to process this status
		} else {
			lineScan = lineScan.replaceAll("\\\".*?\\\"", "");
			lineScan = lineScan.replaceAll("\\\'.*?\\\'", "");
		}
		System.out.println("test: " + lineScan);
	}
	
	public void scanDepend(List<List<String>> inputsDepend, List<String> outputList) {
		System.out.println("========================>scanDepend start:" + mFilename);
		File file = new File(mFilename);
		String name = file.getName();
		System.out.println("name = " + name);
		int index = name.indexOf(".");
		if (index >= 0) {
			className = name.substring(0, index);
		}
		System.out.println("className=" + className);
		if (className.length() == 0) {
			throw new RuntimeException("moduleName empty");
		}
		List<String> content = FileUtils.fileToList(mFilename);
		for (int lineno = 1; lineno <= content.size(); lineno++) {
			String line = content.get(lineno - 1);
			if (line.contains("require") && 
					line.startsWith("var") && //NOTE:startsWith 
					line.contains("=") && line.contains("metamorphose")) {
				Pattern pattern;
				Matcher matcher;
				pattern = Pattern.compile("var\\s+(\\w+)\\s+=", Pattern.MULTILINE);
				matcher = pattern.matcher(line);
				String requireName = "";
				while (matcher.find()) {
					requireName = matcher.group(1);
				}
				if (requireName != null && requireName.length() > 0) {
					inputsDepend.add(Arrays.asList(className, requireName));
					String warning = ">>>>" + "require found" + "[" + requireName + "](" + mFilename + ":" + lineno + ") : " + line;
					System.out.println(warning);
					//outputList.add(warning);
				}
			}
		}
		System.out.println("========================>scanDepend end:" + mFilename);
	}
}
