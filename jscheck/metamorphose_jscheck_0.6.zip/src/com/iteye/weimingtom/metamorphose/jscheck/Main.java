package com.iteye.weimingtom.metamorphose.jscheck;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.iteye.weimingtom.metamorphose.jscheck.sort.Graph;

public class Main {
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: jscheck [path], now use default path: **input**");
			args = new String[]{"input"};
		}
		
		ArrayList<String> fileNames = new ArrayList<String>();
		ListDir(fileNames, args[0]);
		Map<String, List<MemberInfo>> memberInfoMapAll = new HashMap<String, List<MemberInfo>>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.parse();
			String jsClassName = parser.getJSClassName();
			List<MemberInfo> memberInfoMap = parser.getMemberInfoMap();
			memberInfoMapAll.put(jsClassName, memberInfoMap);
		}
		List<String> outputList = new ArrayList<String>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.validate(memberInfoMapAll, outputList);
		}
		FileUtils.listTofile("jscheck.txt", outputList);
		
		for (Map.Entry<String,List<MemberInfo>> entry : memberInfoMapAll.entrySet()) {
			String staticClassName = entry.getKey();
			List<MemberInfo> staticMemberInfo = entry.getValue();
			List<String> dummyJSContentList = new ArrayList<String>(); 
			for (MemberInfo info : staticMemberInfo) {
				if (info.memberScope.equals("constructor")) {
					MemberInfo constructor = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@class " + constructor.memberName);
					dummyJSContentList.add("* " + "@module metamorphose");
					dummyJSContentList.add("* " + "@constructor ");
					if (constructor.baseClassName != null && 
						constructor.baseClassName.length() > 0) {
						dummyJSContentList.add("* " + "@extends " + constructor.baseClassName);
					}
					if (constructor.listArg.size() > 0) {
						for (String param : constructor.listArg) {
							dummyJSContentList.add("* " + "@param {Object} " + param);
						}
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				} else if (info.memberType.equals("function")) {
					MemberInfo func = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@method " + func.memberName);
					if (func.memberScope.equals("static")) {
						dummyJSContentList.add("* " + "@static");
					}
					if (func.listArg.size() > 0) {
						for (String param : func.listArg) {
							dummyJSContentList.add("* " + "@param {Object} " + param);
						}
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				} else if (info.memberType.equals("var")) {
					MemberInfo varMem = info;
					
					dummyJSContentList.add("");
					dummyJSContentList.add("/**");
					dummyJSContentList.add("* ");
					dummyJSContentList.add("* " + "@property " + varMem.memberName);
					dummyJSContentList.add("* " + "@type Object");
					if (varMem.memberScope.equals("static")) {
						dummyJSContentList.add("* " + "@final");
					}
					dummyJSContentList.add("*/");
					dummyJSContentList.add("");
				}
			}
			FileUtils.listTofile("output/" + staticClassName + ".js", dummyJSContentList);
		}
		
		List<String> outputListDepend = new ArrayList<String>();
		List<List<String>> inputsDepend = new ArrayList<List<String>>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.scanDepend(inputsDepend, outputListDepend);
		}
		List<String> outputDepend = new ArrayList<String>();
		Map<String, List<String>> outputLoop = new TreeMap<String, List<String>>();
		boolean result = Graph.topologicalSort(inputsDepend, outputDepend, outputLoop);
		String resultStr = "result:" + result + ", output:" + outputDepend.toString();
		//System.out.println(resultStr);
		outputListDepend.add(resultStr);
		for (int i = outputDepend.size() - 1; i >= 0; i--) {
			String className = outputDepend.get(i);
			String classFilename = "";
			for (String filename : fileNames) {
				File file = new File(filename);
				if (file.getName().equals(className + ".js")) {
					classFilename = filename;
					break;
				}
			}
			classFilename = classFilename.replace("\\", "/");
			if (classFilename.startsWith(args[0])) {
				classFilename = classFilename.substring(args[0].length());
			}
			if (classFilename.startsWith("/")) {
				classFilename = classFilename.substring(1);
			}
			if (classFilename.length() > 0) {
				resultStr = "<script type=\"text/javascript\" src=\"" + classFilename + "\" charset=\"utf-8\"></script>";
				outputListDepend.add(resultStr);
			}
		}
		if (result == false) {
			for (Map.Entry<String, List<String>> entry : outputLoop.entrySet()) {
				boolean found = false;
				for (Map.Entry<String, List<String>> entry2 : outputLoop.entrySet()) {
					if (entry2.getValue().indexOf(entry.getKey()) >= 0) {
						found = true;
						break;
					}
				}
				if (found) {
					resultStr = ">>>" + entry.getKey() + ", in from node:" + entry.getValue().toString();
				} else {
					resultStr = ">>>[endpoint]" + entry.getKey() + ", in from node:" + entry.getValue().toString();
				}
				//System.out.println(resultStr);
				outputListDepend.add(resultStr);
			}
		}
		FileUtils.listTofile("jscheck_depend.txt", outputListDepend);
	}
	
	private static void ListDir(List<String> fileNames, String dirName) {
		ListFiles(fileNames, new File(dirName));
	}

	private static void ListFiles(List<String> fileNames, File dir) {
		if (dir == null || !dir.exists() || !dir.isDirectory()) {
			return;
		}
		String separator = System.getProperty("file.separator");
		String[] files = dir.list();
		for (int i = 0; i < files.length; i++) {
			File file = new File(dir, files[i]);
			String fileName = dir + separator + file.getName();
			if (file.isFile()) {
				//System.out.println(fileName + "\t" + file.length());
				if (fileName != null && fileName.endsWith(".js")) {
					fileNames.add(fileName);
				}
			} else {
				// System.out.println(fileName + "\t<dir>");
				ListFiles(fileNames, file);
			}
		}
	}
}
