package com.iteye.weimingtom.metamorphose.jscheck.sort;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class GraphTest {
	public static void testNormal() {
		List<List<String>> inputs = new ArrayList<List<String>>();
		inputs.add(Arrays.asList("myclass", "jquery", "jquery.cookie", "underscore",  "base"));
		inputs.add(Arrays.asList("jquery",  "base"));
		inputs.add(Arrays.asList("jquery.cookie", "jquery",  "base"));
		inputs.add(Arrays.asList("underscore", "jquery", "base"));
		testAll(inputs);
	}

	public static void testSimple() {
		List<List<String>> inputs = new ArrayList<List<String>>();
		inputs.add(Arrays.asList("a", "c", "b"));
		inputs.add(Arrays.asList("c", "b"));
		testAll(inputs);
	}

	public static void testCycle() {
		List<List<String>> inputs = new ArrayList<List<String>>();
		inputs.add(Arrays.asList("a", "b"));
		inputs.add(Arrays.asList("b", "a"));
		testAll(inputs);
	}

	public static void testSingle() {
		List<List<String>> inputs = new ArrayList<List<String>>();
		inputs.add(Arrays.asList("a"));
		testAll(inputs);
	}
	
	public static void testCycle2() {
		List<List<String>> inputs = new ArrayList<List<String>>();
		inputs.add(Arrays.asList("a", "b"));
		inputs.add(Arrays.asList("b", "d"));
		inputs.add(Arrays.asList("d", "c"));
		inputs.add(Arrays.asList("c", "b"));
		inputs.add(Arrays.asList("d", "e"));
		testAll(inputs);
	}

	
	private static void testAll(List<List<String>> inputs) {
		List<String> output = new ArrayList<String>();
		Map<String, List<String>> outputLoop = new TreeMap<String, List<String>>();
		boolean result = Graph.topologicalSort(inputs, output, outputLoop);
		System.out.println("result:" + result + ", output:" + output.toString());
		if (result == false) {
			for (Map.Entry<String, List<String>> entry : outputLoop.entrySet()) {
				boolean found = false;
				for (Map.Entry<String, List<String>> entry2 : outputLoop.entrySet()) {
					if (entry2.getValue().indexOf(entry.getKey()) >= 0) {
						found = true;
						break;
					}
				}
				if (found) {
					System.out.println(">>>" + entry.getKey() + ", in from node:" + entry.getValue().toString());
				} else {
					System.out.println(">>>[endpoint]" + entry.getKey() + ", in from node:" + entry.getValue().toString());
				}
			}
		}
	}
	
	public static void main(String[] args) {
		testNormal();
		testSimple();
		testCycle();
		testSingle();
		testCycle2();
	}
}
