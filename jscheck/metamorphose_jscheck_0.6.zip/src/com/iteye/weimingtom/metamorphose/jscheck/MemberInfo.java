package com.iteye.weimingtom.metamorphose.jscheck;

import java.util.List;

public class MemberInfo {
	String memberName;
	String memberScope;
	String memberType;
	String baseClassName;
	List<String> listArg; 
}
