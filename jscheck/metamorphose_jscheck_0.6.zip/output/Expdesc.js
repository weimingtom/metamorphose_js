
/**
* 
* @class Expdesc
* @module metamorphose
* @constructor 
*/


/**
* 
* @property VVOID
* @type Object
* @final
*/


/**
* 
* @property VNIL
* @type Object
* @final
*/


/**
* 
* @property VTRUE
* @type Object
* @final
*/


/**
* 
* @property VFALSE
* @type Object
* @final
*/


/**
* 
* @property VK
* @type Object
* @final
*/


/**
* 
* @property VKNUM
* @type Object
* @final
*/


/**
* 
* @property VLOCAL
* @type Object
* @final
*/


/**
* 
* @property VUPVAL
* @type Object
* @final
*/


/**
* 
* @property VGLOBAL
* @type Object
* @final
*/


/**
* 
* @property VINDEXED
* @type Object
* @final
*/


/**
* 
* @property VJMP
* @type Object
* @final
*/


/**
* 
* @property VRELOCABLE
* @type Object
* @final
*/


/**
* 
* @property VNONRELOC
* @type Object
* @final
*/


/**
* 
* @property VCALL
* @type Object
* @final
*/


/**
* 
* @property VVARARG
* @type Object
* @final
*/


/**
* 
* @method init
* @param {Object} kind
* @param {Object} i
*/


/**
* 
* @method copy
* @param {Object} e
*/


/**
* 
* @method getKind
*/


/**
* 
* @method setKind
* @param {Object} kind
*/


/**
* 
* @method getK
*/


/**
* 
* @method setK
* @param {Object} kind
*/


/**
* 
* @method getInfo
*/


/**
* 
* @method setInfo
* @param {Object} i
*/


/**
* 
* @method getAux
*/


/**
* 
* @method setAux
* @param {Object} aux
*/


/**
* 
* @method getNval
*/


/**
* 
* @method setNval
* @param {Object} d
*/


/**
* 
* @method hasmultret
*/


/**
* 
* @method hasjumps
*/


/**
* 
* @method nonreloc
* @param {Object} i
*/


/**
* 
* @method reloc
* @param {Object} i
*/


/**
* 
* @method upval
* @param {Object} i
*/


/**
* 
* @method getF
*/


/**
* 
* @method setF
* @param {Object} f
*/


/**
* 
* @method getT
*/


/**
* 
* @method setT
* @param {Object} t
*/


/**
* 
* @property _k
* @type Object
*/


/**
* 
* @property _info
* @type Object
*/


/**
* 
* @property _aux
* @type Object
*/


/**
* 
* @property _nval
* @type Object
*/


/**
* 
* @property _t
* @type Object
*/


/**
* 
* @property _f
* @type Object
*/

