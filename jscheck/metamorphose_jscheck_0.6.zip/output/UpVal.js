
/**
* 
* @class UpVal
* @module metamorphose
* @constructor 
* @param {Object} offset
* @param {Object} s
*/


/**
* 
* @method getValue
*/


/**
* 
* @method setValue
* @param {Object} o
*/


/**
* 
* @method getOffset
*/


/**
* 
* @method close
*/


/**
* 
* @property _offset
* @type Object
*/


/**
* 
* @property _s
* @type Object
*/

