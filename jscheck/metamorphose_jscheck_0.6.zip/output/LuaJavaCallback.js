
/**
* 
* @class LuaJavaCallback
* @module metamorphose
* @constructor 
* @param {Object} L
*/

