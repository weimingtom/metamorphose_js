
/**
* 
* @class RuntimeException
* @module metamorphose
* @constructor 
* @extends Error
* @param {Object} str
*/


/**
* 
* @property prototype
* @type Object
* @final
*/


/**
* 
* @property message
* @type Object
*/

