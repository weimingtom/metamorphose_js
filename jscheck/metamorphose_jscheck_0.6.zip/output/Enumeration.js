
/**
* 
* @class Enumeration
* @module metamorphose
* @constructor 
*/


/**
* 
* @method hasMoreElements
*/


/**
* 
* @method nextElement
*/

