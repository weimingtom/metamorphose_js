
/**
* 
* @class StringReader
* @module metamorphose
* @constructor 
* @param {Object} s
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} limit
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method readMultiBytes
* @param {Object} cbuf
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method reset
*/


/**
* 
* @property _s
* @type Object
*/


/**
* 
* @property _current
* @type Object
*/


/**
* 
* @property _mark
* @type Object
*/

