
/**
* 
* @class ByteArray
* @module metamorphose
* @constructor 
*/


/**
* 
* @method clear
*/


/**
* 
* @method writeBytes
* @param {Object} b
* @param {Object} off
* @param {Object} len
*/


/**
* 
* @method writeMultiByte
* @param {Object} str
* @param {Object} charset
*/

