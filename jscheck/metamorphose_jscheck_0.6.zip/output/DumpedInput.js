
/**
* 
* @class DumpedInput
* @module metamorphose
* @constructor 
* @param {Object} s
*/


/**
* 
* @method available
*/


/**
* 
* @method close
*/


/**
* 
* @method mark
* @param {Object} readlimit
*/


/**
* 
* @method markSupported
*/


/**
* 
* @method read
*/


/**
* 
* @method reset
*/


/**
* 
* @method skip
* @param {Object} n
*/


/**
* 
* @property _s
* @type Object
*/


/**
* 
* @property _i
* @type Object
*/


/**
* 
* @property _mark
* @type Object
*/

