
/**
* 
* @class DumpState
* @module metamorphose
* @constructor 
* @param {Object} writer
* @param {Object} strip
*/


/**
* 
* @method DumpHeader
*/


/**
* 
* @method DumpInt
* @param {Object} i
*/


/**
* 
* @method DumpNumber
* @param {Object} d
*/


/**
* 
* @method DumpFunction
* @param {Object} f
* @param {Object} p
*/


/**
* 
* @method DumpCode
* @param {Object} f
*/


/**
* 
* @method DumpConstants
* @param {Object} f
*/


/**
* 
* @method DumpString
* @param {Object} s
*/


/**
* 
* @method DumpDebug
* @param {Object} f
*/


/**
* 
* @method getWriter
*/


/**
* 
* @property _writer
* @type Object
*/


/**
* 
* @property _strip
* @type Object
*/

