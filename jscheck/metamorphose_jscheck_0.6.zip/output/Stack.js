
/**
* 
* @class Stack
* @module metamorphose
* @constructor 
*/


/**
* 
* @method addElement
* @param {Object} o
*/


/**
* 
* @method lastElement
*/


/**
* 
* @method getSize
*/


/**
* 
* @method setSize
* @param {Object} size
*/


/**
* 
* @method pop
*/


/**
* 
* @method elementAt
* @param {Object} i
*/


/**
* 
* @property _arr
* @type Object
*/

