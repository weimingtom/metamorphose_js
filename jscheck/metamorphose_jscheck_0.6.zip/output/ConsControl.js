
/**
* 
* @class ConsControl
* @module metamorphose
* @constructor 
* @param {Object} t
*/


/**
* 
* @property v
* @type Object
*/


/**
* 
* @property t
* @type Object
*/


/**
* 
* @property nh
* @type Object
*/


/**
* 
* @property na
* @type Object
*/


/**
* 
* @property tostore
* @type Object
*/

