
/**
* 
* @class MathLib
* @module metamorphose
* @constructor 
* @param {Object} which
*/


/**
* 
* @property ABS
* @type Object
* @final
*/


/**
* 
* @property CEIL
* @type Object
* @final
*/


/**
* 
* @property COS
* @type Object
* @final
*/


/**
* 
* @property DEG
* @type Object
* @final
*/


/**
* 
* @property EXP
* @type Object
* @final
*/


/**
* 
* @property FLOOR
* @type Object
* @final
*/


/**
* 
* @property FMOD
* @type Object
* @final
*/


/**
* 
* @property MAX
* @type Object
* @final
*/


/**
* 
* @property MIN
* @type Object
* @final
*/


/**
* 
* @property MODF
* @type Object
* @final
*/


/**
* 
* @property POW
* @type Object
* @final
*/


/**
* 
* @property RAD
* @type Object
* @final
*/


/**
* 
* @property RANDOM
* @type Object
* @final
*/


/**
* 
* @property RANDOMSEED
* @type Object
* @final
*/


/**
* 
* @property SIN
* @type Object
* @final
*/


/**
* 
* @property SQRT
* @type Object
* @final
*/


/**
* 
* @property TAN
* @type Object
* @final
*/


/**
* 
* @property _rng
* @type Object
* @final
*/


/**
* 
* @method luaFunction
* @param {Object} L
*/


/**
* 
* @method open
* @static
* @param {Object} L
*/


/**
* 
* @method r
* @static
* @param {Object} L
* @param {Object} name
* @param {Object} which
*/


/**
* 
* @method abs
* @static
* @param {Object} L
*/


/**
* 
* @method ceil
* @static
* @param {Object} L
*/


/**
* 
* @method cos
* @static
* @param {Object} L
*/


/**
* 
* @method deg
* @static
* @param {Object} L
*/


/**
* 
* @method exp
* @static
* @param {Object} L
*/


/**
* 
* @method floor
* @static
* @param {Object} L
*/


/**
* 
* @method fmod
* @static
* @param {Object} L
*/


/**
* 
* @method max
* @static
* @param {Object} L
*/


/**
* 
* @method min
* @static
* @param {Object} L
*/


/**
* 
* @method modf
* @static
* @param {Object} L
*/


/**
* 
* @method pow
* @static
* @param {Object} L
*/


/**
* 
* @method rad
* @static
* @param {Object} L
*/


/**
* 
* @method random
* @static
* @param {Object} L
*/


/**
* 
* @method randomseed
* @static
* @param {Object} L
*/


/**
* 
* @method sin
* @static
* @param {Object} L
*/


/**
* 
* @method sqrt
* @static
* @param {Object} L
*/


/**
* 
* @method tan
* @static
* @param {Object} L
*/


/**
* 
* @property _which
* @type Object
*/

