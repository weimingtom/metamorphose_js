package com.iteye.weimingtom.metamorphose.jscheck;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: jscheck [path], now use default path: **input**");
			args = new String[]{"input"};
		}
		
		ArrayList<String> fileNames = new ArrayList<String>();
		ListDir(fileNames, args[0]);
		Map<String, List<MemberInfo>> memberInfoMapAll = new HashMap<String, List<MemberInfo>>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.parse();
			String jsClassName = parser.getJSClassName();
			List<MemberInfo> memberInfoMap = parser.getMemberInfoMap();
			memberInfoMapAll.put(jsClassName, memberInfoMap);
		}
		List<String> outputList = new ArrayList<String>();
		for (String filename : fileNames) {
			JSParser parser = new JSParser(filename);
			parser.validate(memberInfoMapAll, outputList);
		}
		FileUtils.listTofile("jscheck.txt", outputList);
	}
	
	private static void ListDir(List<String> fileNames, String dirName) {
		ListFiles(fileNames, new File(dirName));
	}

	private static void ListFiles(List<String> fileNames, File dir) {
		if (dir == null || !dir.exists() || !dir.isDirectory()) {
			return;
		}
		String separator = System.getProperty("file.separator");
		String[] files = dir.list();
		for (int i = 0; i < files.length; i++) {
			File file = new File(dir, files[i]);
			String fileName = dir + separator + file.getName();
			if (file.isFile()) {
				//System.out.println(fileName + "\t" + file.length());
				if (fileName != null && fileName.endsWith(".js")) {
					fileNames.add(fileName);
				}
			} else {
				// System.out.println(fileName + "\t<dir>");
				ListFiles(fileNames, file);
			}
		}
	}
}
